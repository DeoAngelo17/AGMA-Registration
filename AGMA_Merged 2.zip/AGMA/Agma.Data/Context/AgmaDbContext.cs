using Agma.Data.Configurations;
using Agma.Data.Entities;
using Agma.Data.Views;
using Microsoft.EntityFrameworkCore;

namespace Agma.Data.Context;

/// <summary>
/// Primary DbContext for AGMADB (read/write).
/// Handles registrations, users, venues, cooperatives, and reporting views.
/// </summary>
public class AgmaDbContext : DbContext
{
    public AgmaDbContext(DbContextOptions<AgmaDbContext> options) : base(options) { }

    // ── Core tables ──
    public DbSet<AGMARegistration> AGMARegistrations => Set<AGMARegistration>();
    public DbSet<ElectricCooperative> ElectricCooperatives => Set<ElectricCooperative>();
    public DbSet<Venue> Venues => Set<Venue>();
    public DbSet<UserAccount> UserAccounts => Set<UserAccount>();
    public DbSet<Role> Roles => Set<Role>();

    // ── SQL Views (read-only) ──
    public DbSet<DailyRegistrationSummaryView> DailyRegistrationSummaries => Set<DailyRegistrationSummaryView>();
    public DbSet<RegistrationDetailView> RegistrationDetails => Set<RegistrationDetailView>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Apply entity configurations
        modelBuilder.ApplyConfiguration(new AGMARegistrationConfiguration());
        modelBuilder.ApplyConfiguration(new VenueConfiguration());
        modelBuilder.ApplyConfiguration(new CooperativeConfiguration());

        // ── UserAccount configuration ──
        modelBuilder.Entity<UserAccount>(entity =>
        {
            entity.ToTable("UserAccounts");
            entity.HasKey(e => e.UserID);
            entity.Property(e => e.UserID).ValueGeneratedOnAdd();
            entity.Property(e => e.Username).HasMaxLength(100).IsRequired();
            entity.HasIndex(e => e.Username).IsUnique();
            entity.Property(e => e.PasswordHash).HasMaxLength(500).IsRequired();
            entity.Property(e => e.FullName).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Email).HasMaxLength(200);
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("SYSUTCDATETIME()");

            entity.HasOne(e => e.Role)
                .WithMany(r => r.Users)
                .HasForeignKey(e => e.RoleID)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // ── Role configuration ──
        modelBuilder.Entity<Role>(entity =>
        {
            entity.ToTable("Roles");
            entity.HasKey(e => e.RoleID);
            entity.Property(e => e.RoleID).ValueGeneratedOnAdd();
            entity.Property(e => e.RoleName).HasMaxLength(50).IsRequired();
            entity.HasIndex(e => e.RoleName).IsUnique();
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("SYSUTCDATETIME()");

            // Seed default roles
            entity.HasData(
                new Role { RoleID = 1, RoleName = "Admin", Description = "Full system access", IsActive = true, CreatedAt = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
                new Role { RoleID = 2, RoleName = "Operator", Description = "Registration operator", IsActive = true, CreatedAt = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc) }
            );
        });

        // ── View mappings (keyless, read-only) ──
        modelBuilder.Entity<DailyRegistrationSummaryView>(entity =>
        {
            entity.HasNoKey();
            entity.ToView("vw_DailyRegistrationSummary");
        });

        modelBuilder.Entity<RegistrationDetailView>(entity =>
        {
            entity.HasNoKey();
            entity.ToView("vw_RegistrationDetail");
        });
    }
}
