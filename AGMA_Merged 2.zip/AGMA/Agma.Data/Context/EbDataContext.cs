using Microsoft.EntityFrameworkCore;

namespace Agma.Data.Context;

/// <summary>
/// Read-only DbContext for EBDATA external database.
/// Contains MEMPROF, CON_MASTER, and MEM_ALINK tables.
/// 
/// IMPORTANT: This context is READ ONLY.
/// Never insert, update, or delete records in EBDATA.
/// </summary>
public class EbDataContext : DbContext
{
    public EbDataContext(DbContextOptions<EbDataContext> options) : base(options) { }

    /// <summary>Member profile table — contains membership numbers and MCO names.</summary>
    public DbSet<MemProf> MemProf => Set<MemProf>();

    /// <summary>Consumer master table — contains account numbers and details.</summary>
    public DbSet<ConMaster> ConMaster => Set<ConMaster>();

    /// <summary>Account link table — connects MEMPROF to CON_MASTER (1-to-many).</summary>
    public DbSet<MemALink> MemALink => Set<MemALink>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // ── MEMPROF ──
        modelBuilder.Entity<MemProf>(entity =>
        {
            entity.ToTable("MEMPROF", "dbo");
            entity.HasKey(e => e.MembershipNo);
            entity.Property(e => e.MembershipNo).HasColumnName("MEMBERSHIP_NO").HasMaxLength(30);
            entity.Property(e => e.MemberName).HasColumnName("MEMBER_NAME").HasMaxLength(250);
            entity.Property(e => e.Address).HasColumnName("ADDRESS").HasMaxLength(500);
            entity.Property(e => e.ContactNo).HasColumnName("CONTACT_NO").HasMaxLength(50);
        });

        // ── CON_MASTER ──
        modelBuilder.Entity<ConMaster>(entity =>
        {
            entity.ToTable("CON_MASTER", "dbo");
            entity.HasKey(e => e.AccountNo);
            entity.Property(e => e.AccountNo).HasColumnName("ACCOUNT_NO").HasMaxLength(30);
            entity.Property(e => e.AccountName).HasColumnName("ACCOUNT_NAME").HasMaxLength(250);
            entity.Property(e => e.Address).HasColumnName("ADDRESS").HasMaxLength(500);
            entity.Property(e => e.Status).HasColumnName("STATUS").HasMaxLength(20);
        });

        // ── MEM_ALINK (junction linking MEMPROF → CON_MASTER) ──
        modelBuilder.Entity<MemALink>(entity =>
        {
            entity.ToTable("MEM_ALINK", "dbo");
            entity.HasKey(e => new { e.MembershipNo, e.AccountNo });
            entity.Property(e => e.MembershipNo).HasColumnName("MEMBERSHIP_NO").HasMaxLength(30);
            entity.Property(e => e.AccountNo).HasColumnName("ACCOUNT_NO").HasMaxLength(30);

            entity.HasOne(e => e.Member)
                .WithMany(m => m.AccountLinks)
                .HasForeignKey(e => e.MembershipNo)
                .OnDelete(DeleteBehavior.NoAction);

            entity.HasOne(e => e.Account)
                .WithMany(c => c.MemberLinks)
                .HasForeignKey(e => e.AccountNo)
                .OnDelete(DeleteBehavior.NoAction);
        });
    }
}

// ── EBDATA entity models (nested for cohesion) ──

/// <summary>Member profile record from EBDATA.dbo.MEMPROF.</summary>
public class MemProf
{
    public string MembershipNo { get; set; } = string.Empty;
    public string MemberName { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string? ContactNo { get; set; }

    public virtual ICollection<MemALink> AccountLinks { get; set; } = new List<MemALink>();
}

/// <summary>Consumer master record from EBDATA.dbo.CON_MASTER.</summary>
public class ConMaster
{
    public string AccountNo { get; set; } = string.Empty;
    public string AccountName { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string? Status { get; set; }

    public virtual ICollection<MemALink> MemberLinks { get; set; } = new List<MemALink>();
}

/// <summary>Account link record connecting MEMPROF to CON_MASTER.</summary>
public class MemALink
{
    public string MembershipNo { get; set; } = string.Empty;
    public string AccountNo { get; set; } = string.Empty;

    public virtual MemProf Member { get; set; } = null!;
    public virtual ConMaster Account { get; set; } = null!;
}
