namespace Agma.Data.StoredProcedures;

/// <summary>
/// Result from executing [dbo].[usp_RegisterAGMA].
/// </summary>
public class UspRegisterAGMAResult
{
    public string NewTicketNo { get; set; } = string.Empty;
    public long NewNo { get; set; }
}
