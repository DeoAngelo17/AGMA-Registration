using Agma.Data.Context;
using Agma.Data.Entities;
using Agma.Data.Repositories.Base;
using Agma.Data.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Agma.Data.Repositories;

public class UserRepository : GenericRepository<UserAccount>, IUserRepository
{
    public UserRepository(AgmaDbContext context) : base(context) { }

    public async Task<UserAccount?> GetByUsernameAsync(string username, CancellationToken ct = default)
        => await _dbSet
            .Include(u => u.Role)
            .FirstOrDefaultAsync(u => u.Username == username && u.IsActive, ct);

    public async Task<bool> UsernameExistsAsync(string username, CancellationToken ct = default)
        => await _dbSet.AnyAsync(u => u.Username == username, ct);
}
