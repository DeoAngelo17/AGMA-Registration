using Agma.Data.Context;
using Agma.Data.Entities;
using Agma.Data.Repositories.Base;
using Agma.Data.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Agma.Data.Repositories;

public class VenueRepository : GenericRepository<Venue>, IVenueRepository
{
    public VenueRepository(AgmaDbContext context) : base(context) { }

    public async Task<IEnumerable<Venue>> GetByCoopIdAsync(int coopId, CancellationToken ct = default)
        => await _dbSet.AsNoTracking()
            .Where(v => v.CoopID == coopId && v.IsActive)
            .OrderBy(v => v.VenueName)
            .ToListAsync(ct);

    public async Task<IEnumerable<Venue>> GetActiveAsync(CancellationToken ct = default)
        => await _dbSet.AsNoTracking()
            .Where(v => v.IsActive)
            .Include(v => v.Cooperative)
            .OrderBy(v => v.VenueName)
            .ToListAsync(ct);
}
