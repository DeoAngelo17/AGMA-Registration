using Agma.Data.Context;
using Agma.Data.Entities;
using Agma.Data.Repositories.Base;
using Agma.Data.Repositories.Interfaces;
using Agma.Data.Views;
using Microsoft.EntityFrameworkCore;

namespace Agma.Data.Repositories;

public class AGMARegistrationRepository : GenericRepository<AGMARegistration>, IAGMARegistrationRepository
{
    private readonly AgmaDbContext _db;

    public AGMARegistrationRepository(AgmaDbContext context) : base(context)
    {
        _db = context;
    }

    public async Task<bool> IsMembershipRegisteredAsync(string membershipNo, CancellationToken ct = default)
        => await _dbSet.AnyAsync(r => r.MembershipNo == membershipNo && !r.IsVoided, ct);

    public async Task<bool> IsTicketNoExistsAsync(string ticketNo, CancellationToken ct = default)
        => await _dbSet.AnyAsync(r => r.TicketNo == ticketNo, ct);

    public async Task<AGMARegistration?> GetByTicketNoAsync(string ticketNo, CancellationToken ct = default)
        => await _dbSet.AsNoTracking()
            .Include(r => r.VenueNavigation)
            .Include(r => r.Cooperative)
            .FirstOrDefaultAsync(r => r.TicketNo == ticketNo, ct);

    public async Task<AGMARegistration?> GetByMembershipNoAsync(string membershipNo, CancellationToken ct = default)
        => await _dbSet.AsNoTracking()
            .Include(r => r.VenueNavigation)
            .Include(r => r.Cooperative)
            .FirstOrDefaultAsync(r => r.MembershipNo == membershipNo && !r.IsVoided, ct);

    public async Task<IEnumerable<AGMARegistration>> GetByDateAsync(DateOnly date, CancellationToken ct = default)
        => await _dbSet.AsNoTracking()
            .Where(r => r.Date == date && !r.IsVoided)
            .OrderBy(r => r.No)
            .ToListAsync(ct);

    public async Task<(IEnumerable<AGMARegistration> Items, int TotalCount)> GetPagedAsync(
        int page, int pageSize, CancellationToken ct = default)
    {
        var query = _dbSet.AsNoTracking()
            .Where(r => !r.IsVoided)
            .OrderByDescending(r => r.No);

        var totalCount = await query.CountAsync(ct);
        var items = await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        return (items, totalCount);
    }

    public async Task<IEnumerable<DailyRegistrationSummaryView>> GetDailySummaryAsync(
        DateOnly? date = null, CancellationToken ct = default)
    {
        var query = _db.DailyRegistrationSummaries.AsNoTracking();

        if (date.HasValue)
            query = query.Where(s => s.Date == date.Value);

        return await query.OrderByDescending(s => s.Date).ToListAsync(ct);
    }

    public async Task<IEnumerable<RegistrationDetailView>> GetRegistrationDetailsAsync(
        DateOnly? dateFrom = null, DateOnly? dateTo = null, CancellationToken ct = default)
    {
        var query = _db.RegistrationDetails.AsNoTracking();

        if (dateFrom.HasValue)
            query = query.Where(r => r.Date >= dateFrom.Value);
        if (dateTo.HasValue)
            query = query.Where(r => r.Date <= dateTo.Value);

        return await query.OrderByDescending(r => r.No).ToListAsync(ct);
    }
}
