using Agma.Data.Entities;
using Agma.Data.Repositories.Base;

namespace Agma.Data.Repositories.Interfaces;

public interface IVenueRepository : IGenericRepository<Venue>
{
    Task<IEnumerable<Venue>> GetByCoopIdAsync(int coopId, CancellationToken ct = default);
    Task<IEnumerable<Venue>> GetActiveAsync(CancellationToken ct = default);
}
