using Agma.Data.Context;

namespace Agma.Data.Repositories.Interfaces;

/// <summary>
/// Read-only repository for EBDATA.
/// Searches MEMPROF + CON_MASTER via MEM_ALINK.
/// </summary>
public interface IEBDataRepository
{
    /// <summary>
    /// Search MCO by name across MEMPROF and CON_MASTER.
    /// Returns grouped results: one membership → many accounts.
    /// </summary>
    Task<IEnumerable<MCOSearchResult>> SearchMCOByNameAsync(
        string name, int maxResults = 50, CancellationToken ct = default);

    /// <summary>
    /// Get all accounts linked to a specific membership number.
    /// </summary>
    Task<MCOSearchResult?> GetByMembershipNoAsync(
        string membershipNo, CancellationToken ct = default);
}

/// <summary>
/// Grouped MCO search result: one membership with all linked accounts.
/// </summary>
public class MCOSearchResult
{
    public string MembershipNo { get; set; } = string.Empty;
    public string MemberName { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string? ContactNo { get; set; }
    public List<LinkedAccount> Accounts { get; set; } = new();
}

/// <summary>
/// A single account linked to a membership.
/// </summary>
public class LinkedAccount
{
    public string AccountNo { get; set; } = string.Empty;
    public string AccountName { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string? Status { get; set; }
}
