using Agma.Data.Entities;
using Agma.Data.Repositories.Base;

namespace Agma.Data.Repositories.Interfaces;

public interface IUserRepository : IGenericRepository<UserAccount>
{
    Task<UserAccount?> GetByUsernameAsync(string username, CancellationToken ct = default);
    Task<bool> UsernameExistsAsync(string username, CancellationToken ct = default);
}
