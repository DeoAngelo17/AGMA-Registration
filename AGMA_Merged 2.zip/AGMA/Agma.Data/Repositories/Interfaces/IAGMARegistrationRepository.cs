using Agma.Data.Entities;
using Agma.Data.Repositories.Base;
using Agma.Data.StoredProcedures;
using Agma.Data.Views;

namespace Agma.Data.Repositories.Interfaces;

public interface IAGMARegistrationRepository : IGenericRepository<AGMARegistration>
{
    /// <summary>Check if a membership number has already been registered.</summary>
    Task<bool> IsMembershipRegisteredAsync(string membershipNo, CancellationToken ct = default);

    /// <summary>Check if a ticket number already exists.</summary>
    Task<bool> IsTicketNoExistsAsync(string ticketNo, CancellationToken ct = default);

    /// <summary>Get registration by ticket number.</summary>
    Task<AGMARegistration?> GetByTicketNoAsync(string ticketNo, CancellationToken ct = default);

    /// <summary>Get registration by membership number.</summary>
    Task<AGMARegistration?> GetByMembershipNoAsync(string membershipNo, CancellationToken ct = default);

    /// <summary>Get all registrations for a specific date.</summary>
    Task<IEnumerable<AGMARegistration>> GetByDateAsync(DateOnly date, CancellationToken ct = default);

    /// <summary>Get all non-voided registrations with pagination.</summary>
    Task<(IEnumerable<AGMARegistration> Items, int TotalCount)> GetPagedAsync(
        int page, int pageSize, CancellationToken ct = default);

    /// <summary>Get daily summary from the SQL view.</summary>
    Task<IEnumerable<DailyRegistrationSummaryView>> GetDailySummaryAsync(
        DateOnly? date = null, CancellationToken ct = default);

    /// <summary>Get detailed registration records from the SQL view.</summary>
    Task<IEnumerable<RegistrationDetailView>> GetRegistrationDetailsAsync(
        DateOnly? dateFrom = null, DateOnly? dateTo = null, CancellationToken ct = default);
}
