using Agma.Data.Entities;
using Agma.Data.Repositories.Base;

namespace Agma.Data.Repositories.Interfaces;

public interface ICooperativeRepository : IGenericRepository<ElectricCooperative>
{
    Task<ElectricCooperative?> GetByCodeAsync(string coopCode, CancellationToken ct = default);
    Task<IEnumerable<ElectricCooperative>> GetActiveAsync(CancellationToken ct = default);
}
