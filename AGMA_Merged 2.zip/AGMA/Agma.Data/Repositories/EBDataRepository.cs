using Agma.Data.Context;
using Agma.Data.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Agma.Data.Repositories;

/// <summary>
/// Read-only repository for searching MCO data in EBDATA.
/// Joins MEMPROF → MEM_ALINK → CON_MASTER and groups by membership.
/// 
/// EBDATA is READ ONLY — no insert/update/delete operations.
/// </summary>
public class EBDataRepository : IEBDataRepository
{
    private readonly EbDataContext _db;

    public EBDataRepository(EbDataContext db)
    {
        _db = db;
    }

    public async Task<IEnumerable<MCOSearchResult>> SearchMCOByNameAsync(
        string name, int maxResults = 50, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(name))
            return Enumerable.Empty<MCOSearchResult>();

        var searchTerm = name.Trim();

        // Search MEMPROF by member name OR CON_MASTER by account name
        // Use a single efficient query with joins
        var results = await (
            from mp in _db.MemProf.AsNoTracking()
            join al in _db.MemALink.AsNoTracking()
                on mp.MembershipNo equals al.MembershipNo
            join cm in _db.ConMaster.AsNoTracking()
                on al.AccountNo equals cm.AccountNo
            where EF.Functions.Like(mp.MemberName, $"%{searchTerm}%")
               || EF.Functions.Like(cm.AccountName, $"%{searchTerm}%")
            select new
            {
                mp.MembershipNo,
                mp.MemberName,
                MemberAddress = mp.Address,
                mp.ContactNo,
                cm.AccountNo,
                cm.AccountName,
                AccountAddress = cm.Address,
                cm.Status
            }
        )
        .Take(maxResults * 5) // Fetch extra rows since we'll group them down
        .ToListAsync(ct);

        // Group by MembershipNo in memory (1 membership = 1 ticket)
        var grouped = results
            .GroupBy(r => r.MembershipNo)
            .Take(maxResults)
            .Select(g => new MCOSearchResult
            {
                MembershipNo = g.Key,
                MemberName = g.First().MemberName,
                Address = g.First().MemberAddress,
                ContactNo = g.First().ContactNo,
                Accounts = g
                    .DistinctBy(a => a.AccountNo)
                    .Select(a => new LinkedAccount
                    {
                        AccountNo = a.AccountNo,
                        AccountName = a.AccountName,
                        Address = a.AccountAddress,
                        Status = a.Status
                    })
                    .ToList()
            })
            .ToList();

        return grouped;
    }

    public async Task<MCOSearchResult?> GetByMembershipNoAsync(
        string membershipNo, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(membershipNo))
            return null;

        var member = await _db.MemProf.AsNoTracking()
            .FirstOrDefaultAsync(m => m.MembershipNo == membershipNo, ct);

        if (member is null)
            return null;

        var accounts = await (
            from al in _db.MemALink.AsNoTracking()
            join cm in _db.ConMaster.AsNoTracking()
                on al.AccountNo equals cm.AccountNo
            where al.MembershipNo == membershipNo
            select new LinkedAccount
            {
                AccountNo = cm.AccountNo,
                AccountName = cm.AccountName,
                Address = cm.Address,
                Status = cm.Status
            }
        ).ToListAsync(ct);

        return new MCOSearchResult
        {
            MembershipNo = member.MembershipNo,
            MemberName = member.MemberName,
            Address = member.Address,
            ContactNo = member.ContactNo,
            Accounts = accounts
        };
    }
}
