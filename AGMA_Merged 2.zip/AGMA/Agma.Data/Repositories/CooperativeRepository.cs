using Agma.Data.Context;
using Agma.Data.Entities;
using Agma.Data.Repositories.Base;
using Agma.Data.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Agma.Data.Repositories;

public class CooperativeRepository : GenericRepository<ElectricCooperative>, ICooperativeRepository
{
    public CooperativeRepository(AgmaDbContext context) : base(context) { }

    public async Task<ElectricCooperative?> GetByCodeAsync(string coopCode, CancellationToken ct = default)
        => await _dbSet.AsNoTracking()
            .FirstOrDefaultAsync(c => c.CoopCode == coopCode, ct);

    public async Task<IEnumerable<ElectricCooperative>> GetActiveAsync(CancellationToken ct = default)
        => await _dbSet.AsNoTracking()
            .Where(c => c.IsActive)
            .OrderBy(c => c.CoopName)
            .ToListAsync(ct);
}
