using Agma.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Agma.Data.Configurations;

public class CooperativeConfiguration : IEntityTypeConfiguration<ElectricCooperative>
{
    public void Configure(EntityTypeBuilder<ElectricCooperative> builder)
    {
        builder.ToTable("ElectricCooperatives");
        builder.HasKey(e => e.CoopID);
        builder.Property(e => e.CoopID).ValueGeneratedOnAdd();

        builder.Property(e => e.CoopCode).HasMaxLength(20).IsRequired();
        builder.HasIndex(e => e.CoopCode).IsUnique();

        builder.Property(e => e.CoopName).HasMaxLength(200).IsRequired();
        builder.Property(e => e.Region).HasMaxLength(100);
        builder.Property(e => e.Province).HasMaxLength(100);
        builder.Property(e => e.Municipality).HasMaxLength(100);
        builder.Property(e => e.IsActive).HasDefaultValue(true);
        builder.Property(e => e.CreatedAt).HasDefaultValueSql("SYSUTCDATETIME()");
    }
}
