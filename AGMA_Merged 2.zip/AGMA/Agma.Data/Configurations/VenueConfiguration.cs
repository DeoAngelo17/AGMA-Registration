using Agma.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Agma.Data.Configurations;

public class VenueConfiguration : IEntityTypeConfiguration<Venue>
{
    public void Configure(EntityTypeBuilder<Venue> builder)
    {
        builder.ToTable("Venues");
        builder.HasKey(e => e.VenueID);
        builder.Property(e => e.VenueID).ValueGeneratedOnAdd();

        builder.Property(e => e.VenueName).HasMaxLength(200).IsRequired();
        builder.Property(e => e.Address).HasMaxLength(500);
        builder.Property(e => e.IsActive).HasDefaultValue(true);
        builder.Property(e => e.CreatedAt).HasDefaultValueSql("SYSUTCDATETIME()");

        builder.HasOne(e => e.Cooperative)
            .WithMany(c => c.Venues)
            .HasForeignKey(e => e.CoopID)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
