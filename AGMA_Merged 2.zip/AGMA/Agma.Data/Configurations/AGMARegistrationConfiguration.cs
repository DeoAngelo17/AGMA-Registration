using Agma.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Agma.Data.Configurations;

public class AGMARegistrationConfiguration : IEntityTypeConfiguration<AGMARegistration>
{
    public void Configure(EntityTypeBuilder<AGMARegistration> builder)
    {
        builder.ToTable("AGMARegistration");

        builder.HasKey(e => e.No);
        builder.Property(e => e.No)
            .ValueGeneratedOnAdd();

        builder.Property(e => e.TicketNo)
            .HasMaxLength(30)
            .IsRequired();

        builder.HasIndex(e => e.TicketNo)
            .IsUnique();

        builder.Property(e => e.MembershipNo)
            .HasMaxLength(30)
            .IsRequired();

        builder.Property(e => e.AccountNameOfMCO)
            .HasMaxLength(2000)   // Extended for comma-separated multi-account names
            .IsRequired();

        builder.Property(e => e.AccountNo)
            .HasMaxLength(2000)   // Extended for comma-separated multi-account numbers
            .IsRequired();

        builder.Property(e => e.Date)
            .IsRequired();

        builder.Property(e => e.TimeOfRegistration)
            .IsRequired();

        builder.Property(e => e.Venue)
            .HasMaxLength(200)
            .IsRequired();

        builder.Property(e => e.Remarks)
            .HasMaxLength(50)
            .IsRequired();

        builder.Property(e => e.RegisteredBy)
            .HasMaxLength(100);

        builder.Property(e => e.CreatedAt)
            .HasDefaultValueSql("SYSUTCDATETIME()");

        builder.Property(e => e.IsVoided)
            .HasDefaultValue(false);

        // Relationships
        builder.HasOne(e => e.VenueNavigation)
            .WithMany(v => v.Registrations)
            .HasForeignKey(e => e.VenueID)
            .OnDelete(DeleteBehavior.SetNull);

        builder.HasOne(e => e.Cooperative)
            .WithMany(c => c.Registrations)
            .HasForeignKey(e => e.CoopID)
            .OnDelete(DeleteBehavior.SetNull);

        // Indexes matching the SQL schema
        builder.HasIndex(e => e.MembershipNo)
            .HasDatabaseName("IX_AGMAReg_MembershipNo");

        builder.HasIndex(e => e.AccountNo)
            .HasDatabaseName("IX_AGMAReg_AccountNo");

        builder.HasIndex(e => e.Date)
            .HasDatabaseName("IX_AGMAReg_Date");
    }
}
