namespace Agma.Data.Views;

/// <summary>
/// Maps to [dbo].[vw_DailyRegistrationSummary] in AGMADB.
/// Read-only view entity — no key, not tracked.
/// </summary>
public class DailyRegistrationSummaryView
{
    public DateOnly Date { get; set; }
    public string Venue { get; set; } = string.Empty;
    public string Remarks { get; set; } = string.Empty;
    public int TotalRegistrations { get; set; }
    public TimeOnly EarliestRegistration { get; set; }
    public TimeOnly LatestRegistration { get; set; }
}
