namespace Agma.Data.Views;

/// <summary>
/// Maps to [dbo].[vw_RegistrationDetail] in AGMADB.
/// Read-only view entity — no key, not tracked.
/// </summary>
public class RegistrationDetailView
{
    public long No { get; set; }
    public string TicketNo { get; set; } = string.Empty;
    public string MembershipNo { get; set; } = string.Empty;
    public string AccountNameOfMCO { get; set; } = string.Empty;
    public string AccountNo { get; set; } = string.Empty;
    public DateOnly Date { get; set; }
    public TimeOnly TimeOfRegistration { get; set; }
    public string Venue { get; set; } = string.Empty;
    public string Remarks { get; set; } = string.Empty;
    public string? CoopName { get; set; }
    public string? Region { get; set; }
    public string? Province { get; set; }
    public string? RegisteredBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public bool IsVoided { get; set; }
}
