using Agma.Data.Context;
using Agma.Data.Repositories;
using Agma.Data.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore.Storage;

namespace Agma.Data.UnitOfWork;

/// <summary>
/// Unit of Work implementation wrapping AgmaDbContext.
/// Provides centralized transaction management.
/// </summary>
public class UnitOfWork : IUnitOfWork
{
    private readonly AgmaDbContext _context;
    private IDbContextTransaction? _transaction;
    private bool _disposed;

    // Lazy-initialized repositories
    private IAGMARegistrationRepository? _registrations;
    private ICooperativeRepository? _cooperatives;
    private IVenueRepository? _venues;
    private IUserRepository? _users;

    public UnitOfWork(AgmaDbContext context)
    {
        _context = context;
    }

    public IAGMARegistrationRepository Registrations
        => _registrations ??= new AGMARegistrationRepository(_context);

    public ICooperativeRepository Cooperatives
        => _cooperatives ??= new CooperativeRepository(_context);

    public IVenueRepository Venues
        => _venues ??= new VenueRepository(_context);

    public IUserRepository Users
        => _users ??= new UserRepository(_context);

    public async Task<int> SaveChangesAsync(CancellationToken ct = default)
        => await _context.SaveChangesAsync(ct);

    public async Task BeginTransactionAsync(CancellationToken ct = default)
    {
        _transaction = await _context.Database.BeginTransactionAsync(ct);
    }

    public async Task CommitAsync(CancellationToken ct = default)
    {
        if (_transaction is not null)
        {
            await _transaction.CommitAsync(ct);
            await _transaction.DisposeAsync();
            _transaction = null;
        }
    }

    public async Task RollbackAsync(CancellationToken ct = default)
    {
        if (_transaction is not null)
        {
            await _transaction.RollbackAsync(ct);
            await _transaction.DisposeAsync();
            _transaction = null;
        }
    }

    public void Dispose()
    {
        if (!_disposed)
        {
            _transaction?.Dispose();
            _context.Dispose();
            _disposed = true;
        }
        GC.SuppressFinalize(this);
    }
}
