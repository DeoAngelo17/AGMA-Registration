using Agma.Data.Repositories.Interfaces;

namespace Agma.Data.UnitOfWork;

/// <summary>
/// Unit of Work for centralized transaction management across AGMADB repositories.
/// </summary>
public interface IUnitOfWork : IDisposable
{
    IAGMARegistrationRepository Registrations { get; }
    ICooperativeRepository Cooperatives { get; }
    IVenueRepository Venues { get; }
    IUserRepository Users { get; }

    /// <summary>Persist all changes within the current transaction scope.</summary>
    Task<int> SaveChangesAsync(CancellationToken ct = default);

    /// <summary>Begin an explicit database transaction.</summary>
    Task BeginTransactionAsync(CancellationToken ct = default);

    /// <summary>Commit the current transaction.</summary>
    Task CommitAsync(CancellationToken ct = default);

    /// <summary>Roll back the current transaction.</summary>
    Task RollbackAsync(CancellationToken ct = default);
}
