namespace Agma.Data.Entities;

/// <summary>
/// Registration venue within a cooperative.
/// Maps to [dbo].[Venues] in AGMADB.
/// </summary>
public class Venue
{
    public int VenueID { get; set; }
    public int CoopID { get; set; }
    public string VenueName { get; set; } = string.Empty;
    public string? Address { get; set; }
    public int? Capacity { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }

    // Navigation properties
    public virtual ElectricCooperative Cooperative { get; set; } = null!;
    public virtual ICollection<AGMARegistration> Registrations { get; set; } = new List<AGMARegistration>();
}
