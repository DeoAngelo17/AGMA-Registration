namespace Agma.Data.Entities;

/// <summary>
/// System user account for JWT authentication.
/// Maps to [dbo].[UserAccounts] in AGMADB.
/// </summary>
public class UserAccount
{
    public int UserID { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public int RoleID { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? LastLoginAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }

    // Navigation property
    public virtual Role Role { get; set; } = null!;
}
