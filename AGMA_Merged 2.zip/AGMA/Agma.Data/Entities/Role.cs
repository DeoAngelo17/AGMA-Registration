namespace Agma.Data.Entities;

/// <summary>
/// Role-based authorization entity.
/// Maps to [dbo].[Roles] in AGMADB.
/// </summary>
public class Role
{
    public int RoleID { get; set; }
    public string RoleName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }

    // Navigation property
    public virtual ICollection<UserAccount> Users { get; set; } = new List<UserAccount>();
}
