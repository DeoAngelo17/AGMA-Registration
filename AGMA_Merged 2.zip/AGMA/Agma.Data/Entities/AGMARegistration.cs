namespace Agma.Data.Entities;

/// <summary>
/// Core registration record for the AGMA program.
/// Maps to [dbo].[AGMARegistration] in AGMADB.
/// </summary>
public class AGMARegistration
{
    /// <summary>Auto-incrementing primary key.</summary>
    public long No { get; set; }

    /// <summary>Unique ticket reference (admin-entered, e.g. "00001").</summary>
    public string TicketNo { get; set; } = string.Empty;

    /// <summary>MCO membership number — the PRIMARY business identifier.</summary>
    public string MembershipNo { get; set; } = string.Empty;

    /// <summary>Comma-separated account names when MCO owns multiple accounts.</summary>
    public string AccountNameOfMCO { get; set; } = string.Empty;

    /// <summary>Comma-separated account numbers when MCO owns multiple accounts.</summary>
    public string AccountNo { get; set; } = string.Empty;

    /// <summary>Date of registration.</summary>
    public DateOnly Date { get; set; }

    /// <summary>Time the registration was processed.</summary>
    public TimeOnly TimeOfRegistration { get; set; }

    /// <summary>FK to Venues table (optional).</summary>
    public int? VenueID { get; set; }

    /// <summary>Venue name stored as text for flexibility.</summary>
    public string Venue { get; set; } = string.Empty;

    /// <summary>Sequential or Simultaneous.</summary>
    public string Remarks { get; set; } = string.Empty;

    /// <summary>FK to ElectricCooperatives table (optional).</summary>
    public int? CoopID { get; set; }

    /// <summary>Username of the admin who registered this MCO.</summary>
    public string? RegisteredBy { get; set; }

    /// <summary>UTC timestamp when the record was created.</summary>
    public DateTime CreatedAt { get; set; }

    /// <summary>UTC timestamp when the record was last updated.</summary>
    public DateTime? UpdatedAt { get; set; }

    /// <summary>Soft-delete flag.</summary>
    public bool IsVoided { get; set; }

    // Navigation properties
    public virtual Venue? VenueNavigation { get; set; }
    public virtual ElectricCooperative? Cooperative { get; set; }
}
