namespace Agma.Data.Entities;

/// <summary>
/// Lookup table for electric cooperatives.
/// Maps to [dbo].[ElectricCooperatives] in AGMADB.
/// </summary>
public class ElectricCooperative
{
    public int CoopID { get; set; }
    public string CoopCode { get; set; } = string.Empty;
    public string CoopName { get; set; } = string.Empty;
    public string? Region { get; set; }
    public string? Province { get; set; }
    public string? Municipality { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }

    // Navigation properties
    public virtual ICollection<Venue> Venues { get; set; } = new List<Venue>();
    public virtual ICollection<AGMARegistration> Registrations { get; set; } = new List<AGMARegistration>();
}
