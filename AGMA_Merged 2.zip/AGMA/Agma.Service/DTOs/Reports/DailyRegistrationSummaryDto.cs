namespace Agma.Service.DTOs.Reports;

public class DailyRegistrationSummaryDto
{
    public string Date { get; set; } = string.Empty;
    public string Venue { get; set; } = string.Empty;
    public string Remarks { get; set; } = string.Empty;
    public int TotalRegistrations { get; set; }
    public string EarliestRegistration { get; set; } = string.Empty;
    public string LatestRegistration { get; set; } = string.Empty;
}

public class RegistrationDetailDto
{
    public long No { get; set; }
    public string TicketNo { get; set; } = string.Empty;
    public string MembershipNo { get; set; } = string.Empty;
    public string AccountNameOfMCO { get; set; } = string.Empty;
    public string AccountNo { get; set; } = string.Empty;
    public string Date { get; set; } = string.Empty;
    public string TimeOfRegistration { get; set; } = string.Empty;
    public string Venue { get; set; } = string.Empty;
    public string Remarks { get; set; } = string.Empty;
    public string? CoopName { get; set; }
    public string? Region { get; set; }
    public string? Province { get; set; }
    public string? RegisteredBy { get; set; }
    public string CreatedAt { get; set; } = string.Empty;
    public bool IsVoided { get; set; }
}
