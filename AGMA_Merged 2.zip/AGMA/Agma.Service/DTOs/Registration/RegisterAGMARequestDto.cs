namespace Agma.Service.DTOs.Registration;

/// <summary>
/// Request DTO for registering an MCO at the AGMA event.
/// The admin manually enters the ticket number.
/// Account names and numbers are comma-separated when multi-account.
/// </summary>
public class RegisterAGMARequestDto
{
    /// <summary>Admin-entered ticket number (e.g. "00001").</summary>
    public string TicketNo { get; set; } = string.Empty;

    /// <summary>Membership number from EBDATA — primary identifier.</summary>
    public string MembershipNo { get; set; } = string.Empty;

    /// <summary>Comma-separated account names from the grouped search result.</summary>
    public string AccountNameOfMCO { get; set; } = string.Empty;

    /// <summary>Comma-separated account numbers from the grouped search result.</summary>
    public string AccountNo { get; set; } = string.Empty;

    /// <summary>Registration venue name.</summary>
    public string Venue { get; set; } = string.Empty;

    /// <summary>Optional venue ID for FK relationship.</summary>
    public int? VenueID { get; set; }

    /// <summary>Sequential or Simultaneous.</summary>
    public string Remarks { get; set; } = string.Empty;

    /// <summary>Optional cooperative ID.</summary>
    public int? CoopID { get; set; }
}

/// <summary>
/// Result DTO returned after a successful registration.
/// </summary>
public class RegistrationResultDto
{
    public bool Success { get; set; }
    public long No { get; set; }
    public string TicketNo { get; set; } = string.Empty;
    public string MembershipNo { get; set; } = string.Empty;
    public string AccountNameOfMCO { get; set; } = string.Empty;
    public string AccountNo { get; set; } = string.Empty;
    public string Date { get; set; } = string.Empty;
    public string TimeOfRegistration { get; set; } = string.Empty;
    public string Venue { get; set; } = string.Empty;
    public string Remarks { get; set; } = string.Empty;
    public string? RegisteredBy { get; set; }
    public string? Message { get; set; }
}

/// <summary>
/// Search result DTO representing a grouped MCO (1 membership → N accounts).
/// </summary>
public class SearchMemberDto
{
    public string MembershipNo { get; set; } = string.Empty;
    public string MemberName { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string? ContactNo { get; set; }

    /// <summary>All accounts linked to this membership.</summary>
    public List<SearchMemberAccountDto> Accounts { get; set; } = new();

    /// <summary>Pre-joined comma-separated account names for registration.</summary>
    public string CombinedAccountNames => string.Join(", ", Accounts.Select(a => a.AccountName));

    /// <summary>Pre-joined comma-separated account numbers for registration.</summary>
    public string CombinedAccountNumbers => string.Join(", ", Accounts.Select(a => a.AccountNo));

    /// <summary>Whether this membership is already registered in AGMADB.</summary>
    public bool IsAlreadyRegistered { get; set; }
}

public class SearchMemberAccountDto
{
    public string AccountNo { get; set; } = string.Empty;
    public string AccountName { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string? Status { get; set; }
}
