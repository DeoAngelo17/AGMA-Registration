using Agma.Service.DTOs.Registration;
using FluentValidation;

namespace Agma.Service.Validators;

public class RegisterAGMAValidator : AbstractValidator<RegisterAGMARequestDto>
{
    public RegisterAGMAValidator()
    {
        RuleFor(x => x.TicketNo)
            .NotEmpty().WithMessage("Ticket number is required.")
            .MaximumLength(30).WithMessage("Ticket number cannot exceed 30 characters.");

        RuleFor(x => x.MembershipNo)
            .NotEmpty().WithMessage("Membership number is required.")
            .MaximumLength(30).WithMessage("Membership number cannot exceed 30 characters.");

        RuleFor(x => x.AccountNameOfMCO)
            .NotEmpty().WithMessage("Account name of MCO is required.")
            .MaximumLength(2000).WithMessage("Combined account names cannot exceed 2000 characters.");

        RuleFor(x => x.AccountNo)
            .NotEmpty().WithMessage("Account number is required.")
            .MaximumLength(2000).WithMessage("Combined account numbers cannot exceed 2000 characters.");

        RuleFor(x => x.Venue)
            .NotEmpty().WithMessage("Venue is required.")
            .MaximumLength(200).WithMessage("Venue name cannot exceed 200 characters.");

        RuleFor(x => x.Remarks)
            .NotEmpty().WithMessage("Remarks is required.")
            .Must(r => r == "Sequential" || r == "Simultaneous")
            .WithMessage("Remarks must be either 'Sequential' or 'Simultaneous'.");
    }
}
