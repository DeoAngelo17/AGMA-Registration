using Agma.Data.UnitOfWork;
using Agma.Service.DTOs.Reports;
using Agma.Service.Interfaces;
using AutoMapper;
using Microsoft.Extensions.Logging;

namespace Agma.Service.Services;

public class ReportService : IReportService
{
    private readonly IUnitOfWork _uow;
    private readonly IMapper _mapper;
    private readonly ILogger<ReportService> _logger;

    public ReportService(IUnitOfWork uow, IMapper mapper, ILogger<ReportService> logger)
    {
        _uow = uow;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<IEnumerable<DailyRegistrationSummaryDto>> GetDailySummaryAsync(
        DateOnly? date = null, CancellationToken ct = default)
    {
        _logger.LogInformation("Fetching daily summary for date: {Date}", date?.ToString("yyyy-MM-dd") ?? "ALL");

        var views = await _uow.Registrations.GetDailySummaryAsync(date, ct);
        return _mapper.Map<IEnumerable<DailyRegistrationSummaryDto>>(views);
    }

    public async Task<IEnumerable<RegistrationDetailDto>> GetRegistrationDetailsAsync(
        DateOnly? from = null, DateOnly? to = null, CancellationToken ct = default)
    {
        _logger.LogInformation("Fetching registration details — From: {From}, To: {To}",
            from?.ToString("yyyy-MM-dd") ?? "N/A",
            to?.ToString("yyyy-MM-dd") ?? "N/A");

        var views = await _uow.Registrations.GetRegistrationDetailsAsync(from, to, ct);
        return _mapper.Map<IEnumerable<RegistrationDetailDto>>(views);
    }
}
