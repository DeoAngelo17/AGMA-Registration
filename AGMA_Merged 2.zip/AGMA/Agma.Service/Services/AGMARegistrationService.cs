using Agma.Data.Entities;
using Agma.Data.UnitOfWork;
using Agma.Service.DTOs.Registration;
using Agma.Service.Helpers;
using Agma.Service.Interfaces;
using AutoMapper;
using Microsoft.Extensions.Logging;

namespace Agma.Service.Services;

/// <summary>
/// Core registration service implementing the AGMA business rules:
/// - 1 MembershipNo = 1 Ticket only (no duplicates)
/// - Admin enters ticket numbers manually
/// - Account names/numbers stored as comma-separated values
/// - Date and time auto-set at registration time
/// </summary>
public class AGMARegistrationService : IAGMARegistrationService
{
    private readonly IUnitOfWork _uow;
    private readonly IMapper _mapper;
    private readonly ILogger<AGMARegistrationService> _logger;

    public AGMARegistrationService(
        IUnitOfWork uow,
        IMapper mapper,
        ILogger<AGMARegistrationService> logger)
    {
        _uow = uow;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<RegistrationResultDto> RegisterAsync(
        RegisterAGMARequestDto request, string registeredBy, CancellationToken ct = default)
    {
        _logger.LogInformation(
            "Registration attempt — Membership: {MembershipNo}, Ticket: {TicketNo}, By: {RegisteredBy}",
            request.MembershipNo, request.TicketNo, registeredBy);

        // ── Business Rule: 1 MembershipNo = 1 Ticket ONLY ──
        if (await _uow.Registrations.IsMembershipRegisteredAsync(request.MembershipNo, ct))
        {
            _logger.LogWarning("Duplicate registration blocked for MembershipNo: {MembershipNo}", request.MembershipNo);
            return new RegistrationResultDto
            {
                Success = false,
                Message = $"Membership number '{request.MembershipNo}' is already registered."
            };
        }

        // ── Normalize ticket number (zero-pad to 5 digits) ──
        var normalizedTicket = TicketGenerator.Normalize(request.TicketNo);
        if (string.IsNullOrEmpty(normalizedTicket))
        {
            return new RegistrationResultDto
            {
                Success = false,
                Message = "Invalid ticket number."
            };
        }

        // ── Check ticket number uniqueness ──
        if (await _uow.Registrations.IsTicketNoExistsAsync(normalizedTicket, ct))
        {
            _logger.LogWarning("Duplicate ticket number: {TicketNo}", normalizedTicket);
            return new RegistrationResultDto
            {
                Success = false,
                Message = $"Ticket number '{normalizedTicket}' already exists."
            };
        }

        // ── Build the registration entity ──
        var now = DateTime.UtcNow;
        var registration = _mapper.Map<AGMARegistration>(request);
        registration.TicketNo = normalizedTicket;
        registration.Date = DateOnly.FromDateTime(now);
        registration.TimeOfRegistration = TimeOnly.FromDateTime(now);
        registration.RegisteredBy = registeredBy;
        registration.IsVoided = false;

        // ── Persist within a transaction ──
        try
        {
            await _uow.BeginTransactionAsync(ct);

            await _uow.Registrations.AddAsync(registration, ct);
            await _uow.SaveChangesAsync(ct);

            await _uow.CommitAsync(ct);

            _logger.LogInformation(
                "Registration successful — No: {No}, Ticket: {TicketNo}, Membership: {MembershipNo}",
                registration.No, registration.TicketNo, registration.MembershipNo);

            var result = _mapper.Map<RegistrationResultDto>(registration);
            result.Message = "Registration successful.";
            return result;
        }
        catch (Exception ex)
        {
            await _uow.RollbackAsync(ct);
            _logger.LogError(ex, "Registration failed for MembershipNo: {MembershipNo}", request.MembershipNo);
            return new RegistrationResultDto
            {
                Success = false,
                Message = "An error occurred during registration. Please try again."
            };
        }
    }

    public async Task<(IEnumerable<RegistrationResultDto> Items, int TotalCount)> GetAllAsync(
        int page = 1, int pageSize = 50, CancellationToken ct = default)
    {
        var (items, total) = await _uow.Registrations.GetPagedAsync(page, pageSize, ct);
        var dtos = _mapper.Map<IEnumerable<RegistrationResultDto>>(items);
        return (dtos, total);
    }

    public async Task<RegistrationResultDto?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        var reg = await _uow.Registrations.GetByIdAsync(id, ct);
        if (reg is null || reg.IsVoided) return null;
        return _mapper.Map<RegistrationResultDto>(reg);
    }

    public async Task<RegistrationResultDto?> GetByTicketNoAsync(string ticketNo, CancellationToken ct = default)
    {
        var reg = await _uow.Registrations.GetByTicketNoAsync(ticketNo, ct);
        if (reg is null || reg.IsVoided) return null;
        return _mapper.Map<RegistrationResultDto>(reg);
    }
}
