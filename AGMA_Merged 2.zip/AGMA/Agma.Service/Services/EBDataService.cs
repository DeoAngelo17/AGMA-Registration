using Agma.Data.Repositories.Interfaces;
using Agma.Data.UnitOfWork;
using Agma.Service.DTOs.Registration;
using Agma.Service.Interfaces;
using AutoMapper;
using Microsoft.Extensions.Logging;

namespace Agma.Service.Services;

/// <summary>
/// Service for searching MCO data in the EBDATA read-only database.
/// Cross-references AGMADB to flag already-registered memberships.
/// </summary>
public class EBDataService : IEBDataService
{
    private readonly IEBDataRepository _ebDataRepo;
    private readonly IUnitOfWork _uow;
    private readonly IMapper _mapper;
    private readonly ILogger<EBDataService> _logger;

    public EBDataService(
        IEBDataRepository ebDataRepo,
        IUnitOfWork uow,
        IMapper mapper,
        ILogger<EBDataService> logger)
    {
        _ebDataRepo = ebDataRepo;
        _uow = uow;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<IEnumerable<SearchMemberDto>> SearchMCOAsync(
        string name, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Trim().Length < 2)
        {
            _logger.LogDebug("Search term too short: '{Name}'", name);
            return Enumerable.Empty<SearchMemberDto>();
        }

        _logger.LogInformation("Searching EBDATA for MCO name: '{Name}'", name);

        // Search EBDATA (read-only)
        var ebResults = await _ebDataRepo.SearchMCOByNameAsync(name.Trim(), maxResults: 50, ct);

        var dtos = _mapper.Map<List<SearchMemberDto>>(ebResults);

        // Cross-reference each result against AGMADB to check registration status
        foreach (var dto in dtos)
        {
            dto.IsAlreadyRegistered = await _uow.Registrations
                .IsMembershipRegisteredAsync(dto.MembershipNo, ct);
        }

        _logger.LogInformation("EBDATA search returned {Count} results for '{Name}'", dtos.Count, name);

        return dtos;
    }

    public async Task<SearchMemberDto?> GetMCOByMembershipNoAsync(
        string membershipNo, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(membershipNo))
            return null;

        var result = await _ebDataRepo.GetByMembershipNoAsync(membershipNo.Trim(), ct);

        if (result is null)
        {
            _logger.LogDebug("No EBDATA record found for membership '{MembershipNo}'", membershipNo);
            return null;
        }

        var dto = _mapper.Map<SearchMemberDto>(result);
        dto.IsAlreadyRegistered = await _uow.Registrations
            .IsMembershipRegisteredAsync(dto.MembershipNo, ct);

        return dto;
    }
}
