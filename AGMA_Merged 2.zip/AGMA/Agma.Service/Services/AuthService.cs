using Agma.Data.Entities;
using Agma.Data.UnitOfWork;
using Agma.Service.DTOs.Auth;
using Agma.Service.Helpers;
using Agma.Service.Interfaces;
using Microsoft.Extensions.Logging;

namespace Agma.Service.Services;

/// <summary>
/// Authentication service handling login, token generation, and user creation.
/// </summary>
public class AuthService : IAuthService
{
    private readonly IUnitOfWork _uow;
    private readonly JwtHelper _jwt;
    private readonly ILogger<AuthService> _logger;

    public AuthService(IUnitOfWork uow, JwtHelper jwt, ILogger<AuthService> logger)
    {
        _uow = uow;
        _jwt = jwt;
        _logger = logger;
    }

    public async Task<LoginResponseDto> LoginAsync(LoginRequestDto request, CancellationToken ct = default)
    {
        var user = await _uow.Users.GetByUsernameAsync(request.Username, ct);

        if (user is null)
        {
            _logger.LogWarning("Login attempt failed — username '{Username}' not found.", request.Username);
            return new LoginResponseDto
            {
                Success = false,
                Message = "Invalid username or password."
            };
        }

        if (!PasswordHasher.Verify(request.Password, user.PasswordHash))
        {
            _logger.LogWarning("Login attempt failed — invalid password for '{Username}'.", request.Username);
            return new LoginResponseDto
            {
                Success = false,
                Message = "Invalid username or password."
            };
        }

        // Generate JWT
        var (token, expiresAt) = _jwt.GenerateToken(
            user.UserID,
            user.Username,
            user.FullName,
            user.Role.RoleName
        );

        // Update last login timestamp
        user.LastLoginAt = DateTime.UtcNow;
        _uow.Users.Update(user);
        await _uow.SaveChangesAsync(ct);

        _logger.LogInformation("User '{Username}' logged in successfully.", user.Username);

        return new LoginResponseDto
        {
            Success = true,
            Token = token,
            FullName = user.FullName,
            Role = user.Role.RoleName,
            ExpiresAt = expiresAt,
            Message = "Login successful."
        };
    }

    public async Task<bool> CreateUserAsync(
        string username, string password, string fullName, string? email, int roleId,
        CancellationToken ct = default)
    {
        if (await _uow.Users.UsernameExistsAsync(username, ct))
        {
            _logger.LogWarning("Cannot create user — username '{Username}' already exists.", username);
            return false;
        }

        var user = new UserAccount
        {
            Username = username.Trim().ToLower(),
            PasswordHash = PasswordHasher.Hash(password),
            FullName = fullName.Trim(),
            Email = email?.Trim(),
            RoleID = roleId,
            IsActive = true
        };

        await _uow.Users.AddAsync(user, ct);
        await _uow.SaveChangesAsync(ct);

        _logger.LogInformation("User '{Username}' created with role ID {RoleId}.", username, roleId);
        return true;
    }
}
