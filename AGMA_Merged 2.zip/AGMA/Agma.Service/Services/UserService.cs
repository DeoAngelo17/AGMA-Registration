using Agma.Data.Entities;
using Agma.Data.UnitOfWork;
using Agma.Service.Helpers;
using Agma.Service.Interfaces;
using Microsoft.Extensions.Logging;

namespace Agma.Service.Services;

public class UserService : IUserService
{
    private readonly IUnitOfWork _uow;
    private readonly ILogger<UserService> _logger;

    public UserService(IUnitOfWork uow, ILogger<UserService> logger)
    {
        _uow = uow;
        _logger = logger;
    }

    public async Task<bool> CreateUserAsync(
        string username, string password, string fullName, string? email, int roleId,
        CancellationToken ct = default)
    {
        if (await _uow.Users.UsernameExistsAsync(username, ct))
        {
            _logger.LogWarning("Cannot create user — username '{Username}' already exists.", username);
            return false;
        }

        var user = new UserAccount
        {
            Username = username.Trim().ToLower(),
            PasswordHash = PasswordHasher.Hash(password),
            FullName = fullName.Trim(),
            Email = email?.Trim(),
            RoleID = roleId,
            IsActive = true
        };

        await _uow.Users.AddAsync(user, ct);
        await _uow.SaveChangesAsync(ct);

        _logger.LogInformation("User '{Username}' created with role ID {RoleId}.", username, roleId);
        return true;
    }

    public async Task<IEnumerable<UserListDto>> GetAllUsersAsync(CancellationToken ct = default)
    {
        var users = await _uow.Users.GetAllAsync(ct);
        return users.Select(u => new UserListDto
        {
            UserID = u.UserID,
            Username = u.Username,
            FullName = u.FullName,
            Email = u.Email,
            RoleName = u.Role?.RoleName ?? "Unknown",
            IsActive = u.IsActive,
            LastLoginAt = u.LastLoginAt
        });
    }
}
