namespace Agma.Service.Helpers;

/// <summary>
/// Ticket number validation and formatting utility.
/// Admin manually enters ticket numbers (e.g. "00001").
/// </summary>
public static class TicketGenerator
{
    /// <summary>
    /// Pad and normalize a ticket number to 5 digits.
    /// Input: "1" → Output: "00001"
    /// Input: "00042" → Output: "00042"
    /// </summary>
    public static string Normalize(string ticketNo)
    {
        if (string.IsNullOrWhiteSpace(ticketNo))
            return string.Empty;

        var cleaned = ticketNo.Trim();

        // If it's purely numeric, zero-pad to 5 digits
        if (long.TryParse(cleaned, out var num))
            return num.ToString("D5");

        return cleaned;
    }

    /// <summary>
    /// Validate that the ticket number is in an acceptable format.
    /// </summary>
    public static bool IsValid(string ticketNo)
    {
        if (string.IsNullOrWhiteSpace(ticketNo))
            return false;

        var cleaned = ticketNo.Trim();

        // Must be between 1 and 30 characters
        if (cleaned.Length < 1 || cleaned.Length > 30)
            return false;

        return true;
    }
}
