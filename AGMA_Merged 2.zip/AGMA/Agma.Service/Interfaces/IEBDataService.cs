using Agma.Service.DTOs.Registration;

namespace Agma.Service.Interfaces;

/// <summary>
/// Service for searching MCO data in the EBDATA read-only database.
/// </summary>
public interface IEBDataService
{
    /// <summary>
    /// Search MCO by name. Returns grouped results with registration status.
    /// </summary>
    Task<IEnumerable<SearchMemberDto>> SearchMCOAsync(string name, CancellationToken ct = default);

    /// <summary>
    /// Get a specific MCO by membership number with all linked accounts.
    /// </summary>
    Task<SearchMemberDto?> GetMCOByMembershipNoAsync(string membershipNo, CancellationToken ct = default);
}
