namespace Agma.Service.Interfaces;

public interface IUserService
{
    Task<bool> CreateUserAsync(string username, string password, string fullName, string? email, int roleId, CancellationToken ct = default);
    Task<IEnumerable<UserListDto>> GetAllUsersAsync(CancellationToken ct = default);
}

public class UserListDto
{
    public int UserID { get; set; }
    public string Username { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string RoleName { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateTime? LastLoginAt { get; set; }
}
