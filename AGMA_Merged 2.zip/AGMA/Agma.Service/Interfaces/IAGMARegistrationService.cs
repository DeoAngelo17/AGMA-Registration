using Agma.Service.DTOs.Registration;

namespace Agma.Service.Interfaces;

public interface IAGMARegistrationService
{
    /// <summary>Register an MCO. Prevents duplicate membership registrations.</summary>
    Task<RegistrationResultDto> RegisterAsync(RegisterAGMARequestDto request, string registeredBy, CancellationToken ct = default);

    /// <summary>Get all registrations with pagination.</summary>
    Task<(IEnumerable<RegistrationResultDto> Items, int TotalCount)> GetAllAsync(int page = 1, int pageSize = 50, CancellationToken ct = default);

    /// <summary>Get a registration by its auto-incremented No.</summary>
    Task<RegistrationResultDto?> GetByIdAsync(long id, CancellationToken ct = default);

    /// <summary>Get a registration by ticket number.</summary>
    Task<RegistrationResultDto?> GetByTicketNoAsync(string ticketNo, CancellationToken ct = default);
}
