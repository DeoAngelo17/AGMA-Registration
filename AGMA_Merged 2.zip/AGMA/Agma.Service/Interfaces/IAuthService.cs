using Agma.Service.DTOs.Auth;

namespace Agma.Service.Interfaces;

public interface IAuthService
{
    Task<LoginResponseDto> LoginAsync(LoginRequestDto request, CancellationToken ct = default);
    Task<bool> CreateUserAsync(string username, string password, string fullName, string? email, int roleId, CancellationToken ct = default);
}
