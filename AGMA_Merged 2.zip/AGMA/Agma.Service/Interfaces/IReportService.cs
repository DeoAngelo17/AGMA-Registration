using Agma.Service.DTOs.Reports;

namespace Agma.Service.Interfaces;

public interface IReportService
{
    Task<IEnumerable<DailyRegistrationSummaryDto>> GetDailySummaryAsync(DateOnly? date = null, CancellationToken ct = default);
    Task<IEnumerable<RegistrationDetailDto>> GetRegistrationDetailsAsync(DateOnly? from = null, DateOnly? to = null, CancellationToken ct = default);
}
