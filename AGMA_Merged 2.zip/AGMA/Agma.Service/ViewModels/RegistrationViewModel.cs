namespace Agma.Service.ViewModels;

/// <summary>Dashboard statistics for the admin panel.</summary>
public class DashboardViewModel
{
    public int TotalRegistrationsToday { get; set; }
    public int TotalRegistrationsOverall { get; set; }
    public string? CurrentVenue { get; set; }
    public string? LastTicketNo { get; set; }
}

/// <summary>Registration form view model (pre-populated from search).</summary>
public class RegistrationViewModel
{
    public string MembershipNo { get; set; } = string.Empty;
    public string AccountNameOfMCO { get; set; } = string.Empty;
    public string AccountNo { get; set; } = string.Empty;
    public string Venue { get; set; } = string.Empty;
    public string Remarks { get; set; } = string.Empty;
    public string TicketNo { get; set; } = string.Empty;
}

/// <summary>Login form view model.</summary>
public class LoginViewModel
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string? ReturnUrl { get; set; }
    public string? ErrorMessage { get; set; }
}
