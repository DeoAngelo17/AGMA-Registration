using Agma.Data.Entities;
using Agma.Data.Repositories.Interfaces;
using Agma.Data.Views;
using Agma.Service.DTOs.Registration;
using Agma.Service.DTOs.Reports;
using AutoMapper;

namespace Agma.Service.Mapping;

public class AutoMapperProfile : Profile
{
    public AutoMapperProfile()
    {
        // ── Registration entity → DTO ──
        CreateMap<AGMARegistration, RegistrationResultDto>()
            .ForMember(d => d.Success, opt => opt.MapFrom(_ => true))
            .ForMember(d => d.Date, opt => opt.MapFrom(s => s.Date.ToString("yyyy-MM-dd")))
            .ForMember(d => d.TimeOfRegistration, opt => opt.MapFrom(s => s.TimeOfRegistration.ToString("HH:mm:ss")));

        // ── Registration request DTO → entity ──
        CreateMap<RegisterAGMARequestDto, AGMARegistration>()
            .ForMember(d => d.No, opt => opt.Ignore())
            .ForMember(d => d.Date, opt => opt.Ignore())
            .ForMember(d => d.TimeOfRegistration, opt => opt.Ignore())
            .ForMember(d => d.RegisteredBy, opt => opt.Ignore())
            .ForMember(d => d.CreatedAt, opt => opt.Ignore())
            .ForMember(d => d.UpdatedAt, opt => opt.Ignore())
            .ForMember(d => d.IsVoided, opt => opt.Ignore())
            .ForMember(d => d.VenueNavigation, opt => opt.Ignore())
            .ForMember(d => d.Cooperative, opt => opt.Ignore());

        // ── EBDATA search result → DTO ──
        CreateMap<MCOSearchResult, SearchMemberDto>();
        CreateMap<LinkedAccount, SearchMemberAccountDto>();

        // ── SQL View → Report DTOs ──
        CreateMap<DailyRegistrationSummaryView, DailyRegistrationSummaryDto>()
            .ForMember(d => d.Date, opt => opt.MapFrom(s => s.Date.ToString("yyyy-MM-dd")))
            .ForMember(d => d.EarliestRegistration, opt => opt.MapFrom(s => s.EarliestRegistration.ToString("HH:mm:ss")))
            .ForMember(d => d.LatestRegistration, opt => opt.MapFrom(s => s.LatestRegistration.ToString("HH:mm:ss")));

        CreateMap<RegistrationDetailView, RegistrationDetailDto>()
            .ForMember(d => d.Date, opt => opt.MapFrom(s => s.Date.ToString("yyyy-MM-dd")))
            .ForMember(d => d.TimeOfRegistration, opt => opt.MapFrom(s => s.TimeOfRegistration.ToString("HH:mm:ss")))
            .ForMember(d => d.CreatedAt, opt => opt.MapFrom(s => s.CreatedAt.ToString("yyyy-MM-dd HH:mm:ss")));
    }
}
