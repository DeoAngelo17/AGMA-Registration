// ===== AGMA — Dashboard (wired to real API) =====
function Dashboard({ goto, registrations, winners }){
  const [stats, setStats] = useState({ totalRegistrationsToday:0, totalRegistrationsOverall:0 });

  useEffect(()=>{
    API.getDashboard().then(r => {
      if(r.ok && r.data.data) setStats(r.data.data);
    }).catch(()=>{});
  },[]);

  const totalRegs = stats.totalRegistrationsOverall;
  const todayRegs = stats.totalRegistrationsToday;
  const winnersCount = winners ? winners.length : 0;

  return (
    <div className="fade-up">
      <PageHeader
        title="Operations dashboard"
        sub="Real-time view of today's registrations and venue activity."
        right={
          <>
            <button className="btn btn-ghost"><Icon name="calendar"/> {new Date().toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})}</button>
            <button className="btn btn-primary" onClick={()=>goto("search")}><Icon name="plus"/> Register MCO</button>
          </>
        }
      />

      {/* Welcome strip */}
      <div className="glass mb-6" style={{padding:"22px 26px",borderRadius:20,display:"flex",alignItems:"center",gap:24,position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(600px 200px at 20% 50%, rgba(161,99,247,0.18), transparent 60%)",pointerEvents:"none"}}/>
        <div className="brand-mark" style={{width:54,height:54,fontSize:24,borderRadius:14}}>A</div>
        <div style={{flex:1,minWidth:0}}>
          <div className="fw-8" style={{fontSize:20,letterSpacing:"-.015em"}}>Good morning, Administrator</div>
          <div className="tx-dim mt-1" style={{fontSize:13.5}}>
            Assembly day · <span className="tx-violet fw-7">{todayRegs} registered today</span> · {totalRegs} total overall
          </div>
        </div>
        <div className="row gap-3" style={{position:"relative"}}>
          <button className="btn btn-ghost" onClick={()=>goto("draw")}><Icon name="wheel"/> Open Draw</button>
          <button className="btn btn-cyan" onClick={()=>goto("reports")}><Icon name="chart"/> Live Reports</button>
        </div>
      </div>

      {/* Stat grid */}
      <div className="stat-grid mb-6">
        <Stat icon="users"  variant="v" label="MCOs Registered Today" value={todayRegs.toLocaleString()} delta="from AGMADB" />
        <Stat icon="ticket" variant="b" label="Total Registrations" value={totalRegs.toLocaleString()} delta="All time" />
        <Stat icon="trophy" variant="p" label="Winners Drawn" value={winnersCount.toString()} delta="This session" />
        <Stat icon="loc"    variant="g" label="System Status" value="Online" delta="Connected to DB" up/>
      </div>

      {/* Quick actions */}
      <div className="glass mb-6" style={{padding:20,borderRadius:20}}>
        <div className="row between mb-4">
          <div>
            <div className="fw-7" style={{fontSize:15}}>Quick actions</div>
            <div className="tx-dim" style={{fontSize:12.5}}>Common tasks for the registration desk.</div>
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,minmax(0,1fr))",gap:14}}>
          <QuickAction icon="search" title="Search MCO"        sub="Find member by name or no." onClick={()=>goto("search")} variant="v"/>
          <QuickAction icon="list"   title="View Records"      sub="Today & historical regs"    onClick={()=>goto("records")} variant="b"/>
          <QuickAction icon="wheel"  title="Run Prize Draw"    sub="Spin the wheel"              onClick={()=>goto("draw")} variant="p"/>
          <QuickAction icon="chart"  title="Generate Report"   sub="Daily summary"               onClick={()=>goto("reports")} variant="g"/>
        </div>
      </div>

      {/* Recent registrations from backend */}
      <div className="tbl-wrap">
        <div className="tbl-head">
          <div>
            <h3>Recent registrations</h3>
            <div className="sub">Last {Math.min(8,registrations.length)} of {registrations.length}</div>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={()=>goto("records")}>View all <Icon name="chev-r" size={13}/></button>
        </div>
        <div className="tbl-scroll">
          <table className="dt">
            <thead><tr>
              <th style={{width:60}}>No.</th>
              <th>Ticket</th>
              <th>Membership No.</th>
              <th>Account Name of MCO</th>
              <th>Date</th>
              <th>Time</th>
              <th>Venue</th>
              <th>Remarks</th>
            </tr></thead>
            <tbody>
              {registrations.slice(-8).reverse().map((r,i)=>(
                <tr key={r.no || r.ticketNo || i}>
                  <td className="mono tx-mute">{r.no || i+1}</td>
                  <td><span className="badge badge-violet mono">#{r.ticketNo || r.ticket}</span></td>
                  <td className="mono tx-cyan">{r.membershipNo || r.memberId}</td>
                  <td>
                    <div style={{maxWidth:250,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>
                      {r.accountNameOfMCO || (r.names ? r.names.join(", ") : "")}
                    </div>
                  </td>
                  <td className="mono tx-dim">{r.date}</td>
                  <td className="mono tx-dim">{r.timeOfRegistration || r.time}</td>
                  <td className="tx-dim">{r.venue}</td>
                  <td>
                    <span className={"badge "+(r.remarks==="Sequential"?"badge-blue":"badge-pink")}><span className="dot"/>{r.remarks}</span>
                  </td>
                </tr>
              ))}
              {registrations.length === 0 && (
                <tr><td colSpan={8} className="tx-mute" style={{textAlign:"center",padding:40}}>No registrations yet. Use Search to register MCOs.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Stat({ icon, variant, label, value, delta, up }){
  return (
    <div className="stat">
      <div className="stat-head">
        <div className={"stat-icon "+variant}><Icon name={icon} size={18}/></div>
        <div className="badge badge-gray" style={{fontSize:10}}>LIVE</div>
      </div>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      <div className="stat-trend">{delta && <>{up?"↑ ":""}{delta}</>}</div>
    </div>
  );
}

function QuickAction({ icon, title, sub, onClick, variant }){
  return (
    <button className="glass" onClick={onClick} style={{padding:"16px",borderRadius:14,display:"flex",alignItems:"center",gap:14,cursor:"pointer",textAlign:"left",transition:"all .2s ease"}}
      onMouseEnter={(e)=>{e.currentTarget.style.transform="translateY(-2px)";e.currentTarget.style.borderColor="rgba(255,255,255,0.18)"}}
      onMouseLeave={(e)=>{e.currentTarget.style.transform="none";e.currentTarget.style.borderColor=""}}>
      <div className={"stat-icon "+variant} style={{width:42,height:42}}><Icon name={icon} size={18}/></div>
      <div style={{minWidth:0,flex:1}}>
        <div className="fw-7" style={{fontSize:14}}>{title}</div>
        <div className="tx-dim" style={{fontSize:12}}>{sub}</div>
      </div>
      <Icon name="chev-r" size={15} style={{color:"var(--text-mute)"}}/>
    </button>
  );
}

window.Dashboard = Dashboard;
