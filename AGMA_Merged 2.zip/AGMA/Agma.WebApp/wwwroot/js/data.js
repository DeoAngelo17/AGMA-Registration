// ===== Mock data for AGMA 2026 prototype =====

const VENUES = [
  { id: 1, name: "Pavilion Hall A — Main" },
  { id: 2, name: "Pavilion Hall B — Annex" },
  { id: 3, name: "Cooperative Gymnasium" },
  { id: 4, name: "Open Grounds (Tent)" },
];

const TOWNS = ["San Pedro","Bay","Calauan","Los Baños","Pila","Sta. Cruz","Pagsanjan","Cavinti","Liliw","Nagcarlan","Magdalena","Majayjay"];

// "Multi-account" MCOs — admin sees grouped accounts under one membership
const MCO_ROSTER = [
  { id:"MEM-100245", name:"John McDonald", town:"San Pedro", accounts:[
    { name:"John McDonald — House #1", no:"AC-0042-001" },
    { name:"John McDonald — House #2", no:"AC-0042-002" },
    { name:"John McDonald — Farm Lot",  no:"AC-0042-003" },
  ]},
  { id:"MEM-100892", name:"Maria Concepcion Reyes", town:"Bay", accounts:[
    { name:"Maria C. Reyes — Residence", no:"AC-0089-001" },
  ]},
  { id:"MEM-101044", name:"Ramon Aguilar", town:"Calauan", accounts:[
    { name:"Ramon Aguilar — Main", no:"AC-1044-001" },
    { name:"Ramon Aguilar — Sari-Sari Store", no:"AC-1044-002" },
  ]},
  { id:"MEM-101270", name:"Elenita Mariano-Cruz", town:"Los Baños", accounts:[
    { name:"Elenita Cruz — House", no:"AC-1270-001" },
    { name:"E. Cruz — Boarding House A", no:"AC-1270-002" },
    { name:"E. Cruz — Boarding House B", no:"AC-1270-003" },
    { name:"E. Cruz — Workshop", no:"AC-1270-004" },
  ]},
  { id:"MEM-101599", name:"Federico Manlapaz Jr.", town:"Pila", accounts:[
    { name:"Federico Manlapaz Jr. — Residence", no:"AC-1599-001" },
  ]},
  { id:"MEM-102003", name:"Lorna Bituin", town:"Sta. Cruz", accounts:[
    { name:"Lorna Bituin — House", no:"AC-2003-001" },
    { name:"L. Bituin — Bakery", no:"AC-2003-002" },
  ]},
  { id:"MEM-102450", name:"Jose Pedro Magtangol", town:"Pagsanjan", accounts:[
    { name:"Jose Magtangol — Hacienda", no:"AC-2450-001" },
    { name:"J. Magtangol — Resort Annex", no:"AC-2450-002" },
    { name:"J. Magtangol — Riverside Cabin", no:"AC-2450-003" },
  ]},
  { id:"MEM-103104", name:"Imelda Santos-Reyes", town:"Cavinti", accounts:[
    { name:"Imelda Santos — Residence", no:"AC-3104-001" },
  ]},
  { id:"MEM-103441", name:"Bernardo Tuazon", town:"Liliw", accounts:[
    { name:"Bernardo Tuazon — House", no:"AC-3441-001" },
    { name:"B. Tuazon — Carpentry Shop", no:"AC-3441-002" },
  ]},
  { id:"MEM-103889", name:"Cristina Mendoza", town:"Nagcarlan", accounts:[
    { name:"Cristina Mendoza — Residence", no:"AC-3889-001" },
  ]},
  { id:"MEM-104120", name:"Rolando Encarnacion", town:"Magdalena", accounts:[
    { name:"Rolando Encarnacion — Main", no:"AC-4120-001" },
    { name:"R. Encarnacion — Rice Mill", no:"AC-4120-002" },
  ]},
  { id:"MEM-104666", name:"Patricia Villanueva-Lim", town:"Majayjay", accounts:[
    { name:"Patricia Villanueva — Residence", no:"AC-4666-001" },
    { name:"P. Villanueva — Coffee Shop", no:"AC-4666-002" },
    { name:"P. Villanueva — Storage", no:"AC-4666-003" },
  ]},
];

const TODAY = "2026-05-15";

// Pre-existing registrations (today)
const SEED_REGISTRATIONS = [
  { ticket:"00001", memberId:"MEM-099012", names:["Antonio del Rosario"],         accts:["AC-9012-001"],            date:TODAY, time:"08:02 AM", venue:"Pavilion Hall A — Main", remarks:"Sequential" },
  { ticket:"00002", memberId:"MEM-099188", names:["Genevieve Saavedra"],          accts:["AC-9188-001"],            date:TODAY, time:"08:05 AM", venue:"Pavilion Hall A — Main", remarks:"Sequential" },
  { ticket:"00003", memberId:"MEM-099244", names:["Marcelo Bautista","M. Bautista — Tindahan"], accts:["AC-9244-001","AC-9244-002"], date:TODAY, time:"08:11 AM", venue:"Pavilion Hall B — Annex", remarks:"Simultaneous" },
  { ticket:"00004", memberId:"MEM-099407", names:["Rosario Esguerra"],            accts:["AC-9407-001"],            date:TODAY, time:"08:18 AM", venue:"Pavilion Hall A — Main", remarks:"Sequential" },
  { ticket:"00005", memberId:"MEM-099521", names:["Eduardo Manaloto"],            accts:["AC-9521-001"],            date:TODAY, time:"08:24 AM", venue:"Cooperative Gymnasium",  remarks:"Sequential" },
  { ticket:"00006", memberId:"MEM-099644", names:["Teresita Bagsic","T. Bagsic — Boarding"], accts:["AC-9644-001","AC-9644-002"], date:TODAY, time:"08:31 AM", venue:"Pavilion Hall A — Main", remarks:"Simultaneous" },
  { ticket:"00007", memberId:"MEM-099801", names:["Hernando Almazora"],           accts:["AC-9801-001"],            date:TODAY, time:"08:39 AM", venue:"Pavilion Hall B — Annex", remarks:"Sequential" },
  { ticket:"00008", memberId:"MEM-099912", names:["Lucia Pamintuan"],             accts:["AC-9912-001"],            date:TODAY, time:"08:45 AM", venue:"Pavilion Hall A — Main", remarks:"Sequential" },
  { ticket:"00009", memberId:"MEM-100037", names:["Roderick Solis","R. Solis — Workshop","R. Solis — Annex"], accts:["AC-0037-001","AC-0037-002","AC-0037-003"], date:TODAY, time:"08:52 AM", venue:"Cooperative Gymnasium", remarks:"Simultaneous" },
  { ticket:"00010", memberId:"MEM-100150", names:["Annabelle Co"],                accts:["AC-0150-001"],            date:TODAY, time:"09:00 AM", venue:"Pavilion Hall A — Main", remarks:"Sequential" },
  { ticket:"00011", memberId:"MEM-100245", names:["John McDonald — House #1","John McDonald — House #2","John McDonald — Farm Lot"], accts:["AC-0042-001","AC-0042-002","AC-0042-003"], date:TODAY, time:"09:08 AM", venue:"Pavilion Hall A — Main", remarks:"Simultaneous" },
  { ticket:"00012", memberId:"MEM-100412", names:["Wilfredo Esteban"],            accts:["AC-0412-001"],            date:TODAY, time:"09:13 AM", venue:"Open Grounds (Tent)",   remarks:"Sequential" },
  { ticket:"00013", memberId:"MEM-100599", names:["Carmen Bituin"],               accts:["AC-0599-001"],            date:TODAY, time:"09:19 AM", venue:"Pavilion Hall B — Annex", remarks:"Sequential" },
  { ticket:"00014", memberId:"MEM-100702", names:["Salvador Reyes","S. Reyes — Sari-Sari"], accts:["AC-0702-001","AC-0702-002"], date:TODAY, time:"09:27 AM", venue:"Cooperative Gymnasium", remarks:"Simultaneous" },
  { ticket:"00015", memberId:"MEM-100892", names:["Maria Concepcion Reyes"],      accts:["AC-0089-001"],            date:TODAY, time:"09:34 AM", venue:"Pavilion Hall A — Main", remarks:"Sequential" },
];

// Prize list
const PRIZES = [
  "Grand Prize — 32\" Smart TV",
  "1st Prize — Refrigerator",
  "2nd Prize — Microwave Oven",
  "3rd Prize — Electric Fan",
  "Consolation — Grocery Pack",
  "Consolation — Rice Cooker",
];

// Pre-existing winners for the Draw page
const SEED_WINNERS = [
  { ticket:"00003", memberId:"MEM-099244", acct:"AC-9244-001", name:"Marcelo Bautista", town:"Bay", prize:"Consolation — Grocery Pack", claimed:true,  drawnAt:"09:42 AM", status:"Claimed",      timeLeftSec:0 },
  { ticket:"00009", memberId:"MEM-100037", acct:"AC-0037-001", name:"Roderick Solis",   town:"Calauan", prize:"3rd Prize — Electric Fan",  claimed:false, drawnAt:"10:05 AM", status:"Present",      timeLeftSec:240 },
  { ticket:"00006", memberId:"MEM-099644", acct:"AC-9644-001", name:"Teresita Bagsic",  town:"Liliw",   prize:"Consolation — Rice Cooker", claimed:false, drawnAt:"10:12 AM", status:"Not Present",  timeLeftSec:80  },
];

// 30-day registration summary (for reports/dashboard charts)
const DAILY_SUMMARY = (function(){
  const out=[];
  const baseDay = new Date(2026,3,16);
  for(let i=0;i<30;i++){
    const d=new Date(baseDay); d.setDate(d.getDate()+i);
    const w = d.getDay();
    const base = w===0||w===6 ? 60+Math.floor(Math.random()*30) : 110+Math.floor(Math.random()*70);
    out.push({
      date:`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`,
      total:base,
      sequential:Math.round(base*0.62),
      simultaneous:Math.round(base*0.38),
    });
  }
  return out;
})();

window.AGMA_DATA = { VENUES, TOWNS, MCO_ROSTER, SEED_REGISTRATIONS, SEED_WINNERS, PRIZES, DAILY_SUMMARY, TODAY };
