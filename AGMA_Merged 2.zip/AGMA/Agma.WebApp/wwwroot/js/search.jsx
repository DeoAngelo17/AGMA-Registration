// ===== AGMA — Search & Register page (wired to real API) =====
function SearchPage({ registrations, setRegistrations }){
  const toast = useToast();
  const [query, setQuery] = useState("");
  const [stage, setStage] = useState("idle"); // idle | searching | results
  const [results, setResults] = useState([]);
  const [expanded, setExpanded] = useState({});
  const [selected, setSelected] = useState(null); // single MCO object
  const [showPanel, setShowPanel] = useState(false);
  const [successOpen, setSuccessOpen] = useState(false);
  const [lastReg, setLastReg] = useState(null);

  const runSearch = async ()=>{
    if(!query.trim() || query.trim().length < 2){
      toast.err("Too short","Type at least 2 characters to search.");
      return;
    }
    setStage("searching"); setResults([]); setExpanded({}); setSelected(null);

    try {
      const { ok, data } = await API.searchMCO(query.trim());
      if(ok && data.success){
        setResults(data.data || []);
        setStage("results");
        const count = (data.data || []).length;
        if(count === 0) toast.info("No matches", `Couldn't find any MCO for "${query}".`);
        else toast.ok("Search complete", `${count} matching membership${count===1?"":"s"} found.`);
      } else {
        toast.err("Search failed", data.message || "Unknown error");
        setStage("idle");
      }
    } catch(err) {
      toast.err("Connection error", "Could not reach the server.");
      console.error("Search error:", err);
      setStage("idle");
    }
  };

  const clearAll = ()=>{
    setQuery(""); setStage("idle"); setResults([]); setExpanded({}); setSelected(null);
  };

  const selectMCO = (mco)=>{
    if(mco.isAlreadyRegistered){
      toast.err("Already registered", `Membership ${mco.membershipNo} already has a ticket.`);
      return;
    }
    setSelected(mco);
    setShowPanel(true);
  };

  return (
    <div className="fade-up">
      <PageHeader
        title="Search & register MCO"
        sub="Look up a Member Consumer Owner from EBDATA, group their accounts, and issue an assembly ticket."
      />

      {/* Search Card */}
      <div className="glass-strong mb-5" style={{padding:24,borderRadius:22,position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(800px 200px at 0% 0%, rgba(161,99,247,0.16), transparent 60%), radial-gradient(800px 200px at 100% 100%, rgba(69,227,255,0.14), transparent 60%)",pointerEvents:"none"}}/>
        <div style={{position:"relative"}}>
          <div className="row between mb-4">
            <div>
              <div className="fw-8" style={{fontSize:17,letterSpacing:"-.01em"}}>Find a Member Consumer Owner</div>
              <div className="tx-dim" style={{fontSize:13}}>Search by name, membership no., or account number. Multi-account households are auto-grouped.</div>
            </div>
          </div>
          <div className="row gap-3" style={{alignItems:"stretch"}}>
            <div className="field" style={{flex:1,height:56,paddingLeft:18,paddingRight:18,borderRadius:16,position:"relative"}}>
              <span className={"field-icon "+(stage==="searching"?"pulse":"")} style={{fontSize:22,color: stage==="searching"?"#CFB0FF":"var(--text-mute)"}}>
                <Icon name="search" size={20} stroke={2.2}/>
              </span>
              <input
                value={query}
                onChange={(e)=>setQuery(e.target.value)}
                onKeyDown={(e)=>e.key==="Enter" && runSearch()}
                placeholder="e.g. John McDonald, 02-202808159010"
                style={{fontSize:15.5,letterSpacing:"-.005em"}}
                disabled={stage==="searching"}
              />
              {query && stage!=="searching" && (
                <button className="field-icon" style={{background:"none",border:"none",cursor:"pointer"}} onClick={()=>setQuery("")}>
                  <Icon name="x" size={16}/>
                </button>
              )}
            </div>
            <button className="btn btn-primary btn-lg" onClick={runSearch} disabled={stage==="searching"} style={{minWidth:140}}>
              {stage==="searching" ? <><span className="spinner"/> Searching…</> : <><Icon name="search" size={17}/> Search</>}
            </button>
            <button className="btn btn-ghost btn-lg" onClick={clearAll} disabled={stage==="searching"}><Icon name="x" size={17}/> Clear</button>
          </div>
        </div>
      </div>

      {/* Results table */}
      {stage==="results" && (
        <div className="tbl-wrap fade-up">
          <div className="tbl-head">
            <div>
              <h3>Matching MCOs <span className="badge badge-violet mono" style={{marginLeft:8}}>{results.length}</span></h3>
              <div className="sub">Click a row to expand grouped accounts · click Register to issue a ticket</div>
            </div>
          </div>

          {results.length===0 ? (
            <div className="empty">
              <div className="empty-ic"><Icon name="search" size={26}/></div>
              <h4>No matching members</h4>
              <p>Try a partial name or membership number.</p>
              <button className="btn btn-ghost btn-sm mt-3" onClick={clearAll}>Start new search</button>
            </div>
          ) : (
            <div className="tbl-scroll">
              <table className="dt">
                <thead><tr>
                  <th style={{width:50}}></th>
                  <th style={{width:60}}>No.</th>
                  <th>Membership No.</th>
                  <th>Member Name</th>
                  <th>Accounts</th>
                  <th>Combined Account Names</th>
                  <th>Combined Account Nos.</th>
                  <th>Status</th>
                  <th style={{width:120}}>Action</th>
                </tr></thead>
                <tbody>
                  {results.map((m,i)=>{
                    const isMulti = m.accounts && m.accounts.length>1;
                    const isOpen = !!expanded[m.membershipNo];
                    return (
                      <React.Fragment key={m.membershipNo}>
                        <tr className={m.isAlreadyRegistered?"":""}
                            onClick={()=>isMulti && setExpanded(e=>({...e,[m.membershipNo]:!e[m.membershipNo]}))}
                            style={{cursor:isMulti?"pointer":"default", opacity: m.isAlreadyRegistered ? 0.5 : 1}}>
                          <td>
                            {isMulti
                              ? <span className={"expand-btn"+(isOpen?" open":"")}><Icon name="chev-r" size={11} stroke={2.5}/></span>
                              : <span className="tx-mute" style={{fontSize:11}}>—</span>}
                          </td>
                          <td className="mono tx-mute">{String(i+1).padStart(3,"0")}</td>
                          <td className="mono tx-cyan fw-6">{m.membershipNo}</td>
                          <td className="fw-6">{m.memberName}</td>
                          <td>
                            <span className="badge badge-gray mono">{m.accounts ? m.accounts.length : 0}</span>
                          </td>
                          <td style={{maxWidth:260}}>
                            <div className="tx-dim" style={{fontSize:12,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>
                              {m.combinedAccountNames || (m.accounts||[]).map(a=>a.accountName).join(", ")}
                            </div>
                          </td>
                          <td style={{maxWidth:200}}>
                            <div className="mono tx-dim" style={{fontSize:11.5,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>
                              {m.combinedAccountNumbers || (m.accounts||[]).map(a=>a.accountNo).join(", ")}
                            </div>
                          </td>
                          <td>
                            {m.isAlreadyRegistered
                              ? <span className="badge badge-green"><span className="dot"/>Registered</span>
                              : <span className="badge badge-gray"><span className="dot"/>Available</span>}
                          </td>
                          <td onClick={(e)=>e.stopPropagation()}>
                            {m.isAlreadyRegistered
                              ? <span className="tx-mute" style={{fontSize:12}}>Already registered</span>
                              : <button className="btn btn-primary btn-sm" onClick={()=>selectMCO(m)}><Icon name="plus" size={13}/> Register</button>
                            }
                          </td>
                        </tr>
                        {isMulti && isOpen && (
                          <tr className="fade-up" style={{background:"rgba(161,99,247,0.04)"}}>
                            <td colSpan={9} style={{padding:"14px 28px 20px"}}>
                              <div className="row gap-2 mb-3">
                                <span className="badge badge-violet"><Icon name="users" size={11} stroke={2.4}/> Grouped accounts for {m.memberName}</span>
                                <span className="tx-mute" style={{fontSize:12}}>All accounts will register under a single ticket.</span>
                              </div>
                              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:10}}>
                                {(m.accounts||[]).map((a,j)=>(
                                  <div key={j} className="row gap-3" style={{padding:"12px 14px",background:"rgba(255,255,255,0.03)",border:"1px solid var(--glass-border)",borderRadius:12}}>
                                    <div className="stat-icon b" style={{width:34,height:34,fontSize:13}}><Icon name="zap" size={14}/></div>
                                    <div style={{minWidth:0,flex:1}}>
                                      <div className="fw-6" style={{fontSize:13}}>{a.accountName}</div>
                                      <div className="mono tx-mute" style={{fontSize:11.5,marginTop:2}}>{a.accountNo}</div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Empty state when idle */}
      {stage==="idle" && (
        <div className="tbl-wrap fade-up">
          <div className="empty">
            <div className="empty-ic"><Icon name="search" size={26}/></div>
            <h4>Search to begin</h4>
            <p>Enter a member name or membership number above. AGMA will search MEMPROF, CON_MASTER and MEM_ALINK in EBDATA to find the member and group their accounts.</p>
          </div>
        </div>
      )}

      {/* Floating registration panel */}
      {showPanel && selected && (
        <RegistrationPanel
          mco={selected}
          onClose={()=>{ setSelected(null); setShowPanel(false); }}
          onRegistered={(result)=>{
            setLastReg(result);
            setSelected(null); setShowPanel(false);
            setSuccessOpen(true);
            // Refresh registrations list from backend
            API.getRegistrations(1, 200).then(r => {
              if(r.ok && r.data.data) setRegistrations(r.data.data);
            });
          }}
        />
      )}

      <Modal open={successOpen} onClose={()=>setSuccessOpen(false)}>
        {lastReg && (
          <div style={{textAlign:"center"}}>
            <div style={{width:74,height:74,margin:"0 auto 14px",borderRadius:50,background:"linear-gradient(135deg,#3DD68C,#45E3FF)",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 14px 30px -8px rgba(61,214,140,0.55)"}}>
              <Icon name="check" size={36} stroke={3} style={{color:"#0b1335"}}/>
            </div>
            <div className="fw-8" style={{fontSize:22,letterSpacing:"-.015em"}}>Registration successful</div>
            <p className="tx-dim mt-2" style={{fontSize:13.5,maxWidth:380,margin:"6px auto 0"}}>
              MCO registered with ticket <span className="tx-violet fw-7">#{lastReg.ticketNo}</span> at <span className="fw-7">{lastReg.venue}</span>.
            </p>
            <div className="glass mt-4" style={{padding:14,borderRadius:12,textAlign:"left"}}>
              <div className="tx-mute" style={{fontSize:11,textTransform:"uppercase",letterSpacing:".1em",fontWeight:700,marginBottom:6}}>Details</div>
              <div className="row gap-2" style={{flexWrap:"wrap"}}>
                <span className="badge badge-violet mono">#{lastReg.ticketNo}</span>
                <span className="badge badge-cyan mono">{lastReg.membershipNo}</span>
                <span className="badge badge-gray">{lastReg.remarks}</span>
              </div>
            </div>
            <div className="row gap-3 mt-5" style={{justifyContent:"center"}}>
              <button className="btn btn-ghost" onClick={()=>setSuccessOpen(false)}>Continue searching</button>
              <button className="btn btn-primary" onClick={()=>{setSuccessOpen(false); window.dispatchEvent(new CustomEvent("agma:nav",{detail:"records"}))}}>View records <Icon name="chev-r" size={14}/></button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

// Floating registration panel — calls POST /api/registration/register
function RegistrationPanel({ mco, onClose, onRegistered }){
  const toast = useToast();
  const [ticketNo, setTicketNo] = useState("");
  const [venue, setVenue] = useState("Pavilion Hall A — Main");
  const [remarks, setRemarks] = useState(mco.accounts && mco.accounts.length > 1 ? "Simultaneous" : "Sequential");
  const [registering, setRegistering] = useState(false);

  const combinedNames = (mco.accounts||[]).map(a=>a.accountName).join(", ");
  const combinedAccts = (mco.accounts||[]).map(a=>a.accountNo).join(", ");

  const submit = async ()=>{
    if(!ticketNo.trim()){
      toast.err("Missing ticket","Please enter a ticket number.");
      return;
    }
    setRegistering(true);
    try {
      const payload = {
        ticketNo: ticketNo.trim(),
        membershipNo: mco.membershipNo,
        accountNameOfMCO: combinedNames,
        accountNo: combinedAccts,
        venue: venue,
        remarks: remarks,
      };
      const { ok, data } = await API.register(payload);
      if(ok && data.success){
        toast.ok("Registered!", `Ticket #${data.ticketNo} issued for ${mco.memberName}.`);
        onRegistered(data);
      } else {
        toast.err("Registration failed", data.message || (data.errors ? data.errors.join(", ") : "Unknown error"));
      }
    } catch(err) {
      toast.err("Connection error", "Could not reach the server.");
      console.error("Register error:", err);
    } finally {
      setRegistering(false);
    }
  };

  return (
    <div className="reg-panel">
      <div className="row between">
        <div>
          <div className="fw-8" style={{fontSize:17}}>Issue ticket</div>
          <div className="tx-dim" style={{fontSize:12.5}}>{(mco.accounts||[]).length} account{(mco.accounts||[]).length===1?"":"s"} under this membership</div>
        </div>
        <button className="tool-btn" onClick={onClose}><Icon name="x"/></button>
      </div>

      <div className="glass" style={{padding:14,borderRadius:12,marginTop:6}}>
        <div className="tx-mute" style={{fontSize:10.5,letterSpacing:".1em",textTransform:"uppercase",fontWeight:700,marginBottom:6}}>Membership No.</div>
        <div className="mono fw-7 tx-cyan" style={{fontSize:14}}>{mco.membershipNo}</div>
      </div>

      <div>
        <div className="field-label">Ticket No. (admin enters)</div>
        <div className="field">
          <span className="field-icon"><Icon name="ticket" size={16}/></span>
          <input value={ticketNo} onChange={(e)=>setTicketNo(e.target.value)} placeholder="e.g. 00001" autoFocus/>
        </div>
      </div>

      <div>
        <div className="field-label">Combined Account Names</div>
        <div className="glass" style={{padding:"10px 12px",borderRadius:12,maxHeight:140,overflow:"auto"}}>
          {(mco.accounts||[]).map((a,i)=>(
            <div key={i} className="row gap-2" style={{padding:"6px 0",borderBottom: i<(mco.accounts||[]).length-1?"1px solid var(--line)":"none",fontSize:13}}>
              <span className="tx-mute mono" style={{fontSize:11,minWidth:24}}>{String(i+1).padStart(2,"0")}</span>
              <span style={{flex:1,minWidth:0}}>{a.accountName}</span>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="field-label">Combined Account Numbers</div>
        <div className="row gap-2" style={{flexWrap:"wrap"}}>
          {(mco.accounts||[]).map((a,i)=>(<span key={i} className="acct-chip mono">{a.accountNo}</span>))}
        </div>
      </div>

      <div>
        <div className="field-label">Venue</div>
        <div className="field">
          <span className="field-icon"><Icon name="loc" size={16}/></span>
          <select value={venue} onChange={(e)=>setVenue(e.target.value)}>
            {(window.AGMA_DATA?.VENUES || [
              {id:1,name:"Pavilion Hall A — Main"},{id:2,name:"Pavilion Hall B — Annex"},
              {id:3,name:"Cooperative Gymnasium"},{id:4,name:"Open Grounds (Tent)"}
            ]).map(v=><option key={v.id} value={v.name}>{v.name}</option>)}
          </select>
        </div>
      </div>

      <div>
        <div className="field-label">Remarks</div>
        <div className="row gap-2">
          {["Sequential","Simultaneous"].map(opt=>(
            <button key={opt} className={"btn btn-ghost"+(remarks===opt?" active-pill":"")} onClick={()=>setRemarks(opt)} style={{
              flex:1,
              ...(remarks===opt ? { background:"var(--grad-primary)", borderColor:"transparent", color:"#fff" } : {})
            }}>
              <span className="dot" style={{width:8,height:8,borderRadius:50,background:"currentColor",display:"inline-block",marginRight:4}}/>
              {opt}
            </button>
          ))}
        </div>
      </div>

      <div style={{flex:1}}/>
      <div className="row gap-2" style={{marginTop:8}}>
        <button className="btn btn-ghost" onClick={onClose} style={{flex:1}} disabled={registering}>Cancel</button>
        <button className="btn btn-primary" onClick={submit} style={{flex:2}} disabled={registering}>
          {registering ? <><span className="spinner"/> Registering…</> : <><Icon name="check" size={15} stroke={2.6}/> Register</>}
        </button>
      </div>
    </div>
  );
}

window.SearchPage = SearchPage;
