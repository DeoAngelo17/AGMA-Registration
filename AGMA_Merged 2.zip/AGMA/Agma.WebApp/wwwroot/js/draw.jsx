// ===== AGMA — Draw Winners (Spin the Wheel) =====
function DrawPage({ registrations, winners, setWinners }){
  const toast = useToast();
  const [mode, setMode] = useState("ticket"); // ticket | membership
  const [prize, setPrize] = useState(window.AGMA_DATA.PRIZES[0]);
  const [timer, setTimer] = useState(5); // seconds
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [winnerOpen, setWinnerOpen] = useState(false);
  const [lastWinner, setLastWinner] = useState(null);
  const [confettiOn, setConfettiOn] = useState(false);

  // Pool — exclude already-drawn members (by ticket)
  const drawnTickets = new Set(winners.map(w=>w.ticket));
  const pool = useMemo(()=> registrations.filter(r=>!drawnTickets.has(r.ticket)), [registrations, winners]);

  // Build wheel slices (max 18 visible; show count)
  const visibleSlices = pool.slice(0, 18);
  const sliceCount = Math.max(visibleSlices.length, 1);
  const sliceAngle = 360/sliceCount;
  const palette = ["#A163F7","#6F88FC","#45E3FF","#FF7582","#FFB547","#3DD68C"];

  const spin = ()=>{
    if(pool.length===0){ toast.err("No eligible MCOs","Everyone in today's registration pool has already been drawn."); return; }
    setSpinning(true);
    // pick winner
    const winnerIdx = Math.floor(Math.random()*pool.length);
    const winnerReg = pool[winnerIdx];
    // figure out where the winner sits on the wheel
    // if the slice isn't visible, we still snap to its modulo slot
    const targetSliceIdx = winnerIdx % sliceCount;
    const targetAngle = targetSliceIdx*sliceAngle + sliceAngle/2;
    // we want pointer (at top, 0deg) to land at targetAngle → rotate by (360*N - targetAngle)
    const extraSpins = 6 + Math.round(timer/1.2);
    const newRotation = rotation + extraSpins*360 + (360 - targetAngle);
    setRotation(newRotation);

    setTimeout(()=>{
      setSpinning(false);
      // resolve winner data
      const memberRoster = window.AGMA_DATA.MCO_ROSTER.find(m=>m.id===winnerReg.memberId);
      const winRow = {
        ticket: winnerReg.ticket,
        memberId: winnerReg.memberId,
        acct: winnerReg.accts[0],
        name: winnerReg.names[0].split(" — ")[0],
        town: memberRoster?.town || window.AGMA_DATA.TOWNS[Math.floor(Math.random()*window.AGMA_DATA.TOWNS.length)],
        prize: prize,
        claimed: false,
        drawnAt: new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}),
        status: "Present",
        timeLeftSec: 300, // 5 min to claim
      };
      setLastWinner(winRow);
      setWinners(w=>[...w, winRow]);
      setWinnerOpen(true);
      setConfettiOn(true);
      setTimeout(()=>setConfettiOn(false), 2400);
      // advance prize
      const idx = window.AGMA_DATA.PRIZES.indexOf(prize);
      if(idx>=0 && idx<window.AGMA_DATA.PRIZES.length-1) setPrize(window.AGMA_DATA.PRIZES[idx+1]);
    }, 6100); // matches CSS transition (6s) + small buffer
  };

  const stopEarly = ()=>{
    // can't truly stop CSS transition cleanly; just toast
    toast.info("Stop requested", "Wheel will complete its current rotation.");
  };

  const reset = ()=>{
    setRotation(0);
    toast.info("Wheel reset","Rotation set back to neutral position.");
  };

  // countdown ticker for winners
  useEffect(()=>{
    const t = setInterval(()=>{
      setWinners(curr=>curr.map(w=>{
        if(w.status==="Present" && !w.claimed && w.timeLeftSec>0){
          const nl = w.timeLeftSec-1;
          return { ...w, timeLeftSec: nl, status: nl===0 ? "Expired" : w.status };
        }
        return w;
      }));
    }, 1000);
    return ()=>clearInterval(t);
  },[setWinners]);

  return (
    <div className="fade-up">
      <PageHeader
        title="Prize draw"
        sub="Spin the wheel to randomly select winners from today's registered Member Consumer Owners."
        right={
          <>
            <span className="badge badge-violet"><span className="dot"/>{pool.length} eligible</span>
            <span className="badge badge-pink"><span className="dot"/>{winners.length} drawn</span>
          </>
        }
      />

      <Confetti active={confettiOn}/>

      <div className="wheel-stage mb-5">
        {/* Wheel column */}
        <div className="wheel-frame">
          <div className="wheel">
            <div className="wheel-pointer"/>
            <svg className="wheel-disc" viewBox="0 0 200 200" style={{transform:`rotate(${rotation}deg)`}}>
              {Array.from({length:sliceCount}).map((_,i)=>{
                const a0 = (i*sliceAngle - 90) * Math.PI/180;
                const a1 = ((i+1)*sliceAngle - 90) * Math.PI/180;
                const x0 = 100 + 100*Math.cos(a0);
                const y0 = 100 + 100*Math.sin(a0);
                const x1 = 100 + 100*Math.cos(a1);
                const y1 = 100 + 100*Math.sin(a1);
                const large = sliceAngle>180 ? 1 : 0;
                const fill = palette[i%palette.length];
                const label = visibleSlices[i] ? (mode==="ticket" ? "#"+visibleSlices[i].ticket : visibleSlices[i].memberId.replace("MEM-","")) : "";
                const midA = (a0+a1)/2;
                const tx = 100 + 65*Math.cos(midA);
                const ty = 100 + 65*Math.sin(midA);
                const rot = i*sliceAngle + sliceAngle/2;
                return (
                  <g key={i}>
                    <path d={`M100,100 L${x0},${y0} A100,100 0 ${large} 1 ${x1},${y1} Z`}
                      fill={fill}
                      stroke="rgba(255,255,255,0.18)" strokeWidth="0.4"/>
                    <text x={tx} y={ty} fontSize="6" fontWeight="800" fill="#fff"
                      textAnchor="middle" dominantBaseline="middle"
                      transform={`rotate(${rot} ${tx} ${ty})`}
                      style={{textShadow:"0 1px 2px rgba(0,0,0,0.5)",fontFamily:"'JetBrains Mono',monospace"}}>{label}</text>
                  </g>
                );
              })}
              {/* outer ring */}
              <circle cx="100" cy="100" r="99" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.6"/>
              {/* peg dots */}
              {Array.from({length:24}).map((_,i)=>{
                const a = (i/24)*2*Math.PI;
                return <circle key={i} cx={100+95*Math.cos(a)} cy={100+95*Math.sin(a)} r="1.4" fill="#fff" opacity="0.8"/>;
              })}
            </svg>
            <div className="wheel-hub">SPIN</div>
          </div>

          <div className="row gap-3 mt-4" style={{flexWrap:"wrap",justifyContent:"center"}}>
            <button className="btn btn-primary btn-lg" onClick={spin} disabled={spinning || pool.length===0}>
              {spinning ? <><span className="spinner"/> Spinning…</> : <><Icon name="play"/> Start Spin</>}
            </button>
            <button className="btn btn-ghost btn-lg" onClick={stopEarly} disabled={!spinning}>
              <Icon name="pause"/> Stop
            </button>
            <button className="btn btn-ghost btn-lg" onClick={reset} disabled={spinning}>
              <Icon name="reset"/> Reset
            </button>
          </div>

          <div className="row gap-3 mt-3" style={{fontSize:12,color:"var(--text-dim)"}}>
            <span><Icon name="info" size={12} stroke={2.2}/> Showing {visibleSlices.length} of {pool.length} entries on the wheel — full pool is used in selection.</span>
          </div>
        </div>

        {/* Controls column */}
        <div className="glass" style={{padding:22,borderRadius:20,display:"flex",flexDirection:"column",gap:16}}>
          <div>
            <div className="fw-8" style={{fontSize:16,letterSpacing:"-.01em"}}>Draw configuration</div>
            <div className="tx-dim" style={{fontSize:12.5,marginTop:2}}>Configure the next spin before tapping Start.</div>
          </div>

          <div>
            <div className="field-label">Wheel shows</div>
            <div className="tabs" style={{width:"100%"}}>
              <span className={"tab"+(mode==="ticket"?" active":"")} onClick={()=>setMode("ticket")} style={{flex:1,textAlign:"center"}}>Ticket Numbers</span>
              <span className={"tab"+(mode==="membership"?" active":"")} onClick={()=>setMode("membership")} style={{flex:1,textAlign:"center"}}>Membership Numbers</span>
            </div>
          </div>

          <div>
            <div className="field-label">Prize for next spin</div>
            <div className="field">
              <span className="field-icon"><Icon name="trophy" size={16}/></span>
              <select value={prize} onChange={(e)=>setPrize(e.target.value)}>
                {window.AGMA_DATA.PRIZES.map(p=><option key={p}>{p}</option>)}
              </select>
            </div>
          </div>

          <div>
            <div className="field-label">Spin duration · {timer}s</div>
            <input type="range" min="3" max="12" step="1" value={timer} onChange={(e)=>setTimer(+e.target.value)} style={{width:"100%",accentColor:"#A163F7"}}/>
            <div className="row between mt-1 tx-mute" style={{fontSize:11}}>
              <span>Snappy · 3s</span><span>Dramatic · 12s</span>
            </div>
          </div>

          <div className="glass" style={{padding:14,borderRadius:12,background:"rgba(161,99,247,0.08)",borderColor:"rgba(161,99,247,0.25)"}}>
            <div className="tx-mute" style={{fontSize:11,textTransform:"uppercase",letterSpacing:".1em",fontWeight:700}}>Up next</div>
            <div className="fw-7 mt-1" style={{fontSize:14.5}}>{prize}</div>
            <div className="tx-dim mt-2 row gap-2" style={{fontSize:12}}>
              <Icon name="users" size={12} stroke={2.2}/> {pool.length} eligible MCO{pool.length===1?"":"s"} in pool
            </div>
          </div>

          <div className="row gap-2" style={{marginTop:"auto"}}>
            <button className="btn btn-ghost" style={{flex:1}}><Icon name="sparkle" size={14}/> Sound FX</button>
            <button className="btn btn-ghost" style={{flex:1}}><Icon name="settings" size={14}/> Rules</button>
          </div>
        </div>
      </div>

      {/* Winners table */}
      <div className="tbl-wrap">
        <div className="tbl-head">
          <div>
            <h3>Winners <span className="badge badge-pink mono" style={{marginLeft:8}}>{winners.length}</span></h3>
            <div className="sub">Drawn this session · update claim status as winners present themselves</div>
          </div>
          <div className="row gap-2">
            <button className="btn btn-ghost btn-sm"><Icon name="doc" size={14}/> Export PDF</button>
            <button className="btn btn-ghost btn-sm"><Icon name="download" size={14}/> Export Excel</button>
          </div>
        </div>
        <div className="tbl-scroll">
          <table className="dt">
            <thead><tr>
              <th>Ticket No.</th>
              <th>Membership No.</th>
              <th>Account No.</th>
              <th>Name</th>
              <th>Town</th>
              <th>Prize</th>
              <th style={{width:90}}>Claimed</th>
              <th>Drawn At</th>
              <th>Status</th>
              <th>Time Left</th>
              <th style={{minWidth:240}}>Actions</th>
            </tr></thead>
            <tbody>
              {winners.length===0 ? (
                <tr><td colSpan={11}>
                  <div className="empty">
                    <div className="empty-ic"><Icon name="trophy" size={26}/></div>
                    <h4>No winners drawn yet</h4>
                    <p>Tap Start Spin above to draw your first winner. Confetti included.</p>
                  </div>
                </td></tr>
              ) : winners.map((w,i)=>(
                <WinnerRow key={w.ticket+"-"+i} w={w} idx={i} onUpdate={(patch)=>{
                  setWinners(curr=>curr.map((x,j)=>j===i?{...x,...patch}:x));
                }} onRemove={()=>setWinners(curr=>curr.filter((_,j)=>j!==i))}/>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Winner Modal */}
      <Modal open={winnerOpen} onClose={()=>setWinnerOpen(false)} width={500}>
        {lastWinner && (
          <div style={{textAlign:"center"}}>
            <div style={{
              width:90,height:90,margin:"0 auto 14px",borderRadius:50,
              background:"var(--grad-aurora)",
              display:"flex",alignItems:"center",justifyContent:"center",
              boxShadow:"0 20px 50px -10px rgba(161,99,247,0.7)",
              animation:"pulse-ring 1.5s ease-out infinite"
            }}>
              <Icon name="trophy" size={42} stroke={2.2} style={{color:"#fff"}}/>
            </div>
            <div className="tx-mute" style={{fontSize:11,letterSpacing:".14em",textTransform:"uppercase",fontWeight:800}}>Winner</div>
            <div className="fw-8 mt-2" style={{fontSize:30,letterSpacing:"-.02em",background:"var(--grad-aurora)",WebkitBackgroundClip:"text",backgroundClip:"text",color:"transparent",animation:"shimmer 3s linear infinite"}}>{lastWinner.name}</div>
            <div className="row gap-2 mt-3" style={{justifyContent:"center",flexWrap:"wrap"}}>
              <span className="badge badge-violet mono">Ticket #{lastWinner.ticket}</span>
              <span className="badge badge-cyan mono">{lastWinner.memberId}</span>
              <span className="badge badge-pink">{lastWinner.town}</span>
            </div>
            <div className="glass mt-4" style={{padding:14,borderRadius:12}}>
              <div className="tx-mute" style={{fontSize:11,letterSpacing:".1em",textTransform:"uppercase",fontWeight:700}}>Prize</div>
              <div className="fw-8 mt-1" style={{fontSize:18}}>{lastWinner.prize}</div>
              <div className="tx-dim mt-2" style={{fontSize:12.5}}>Claim within 5 minutes or the prize will be forfeited.</div>
            </div>
            <div className="row gap-3 mt-5" style={{justifyContent:"center"}}>
              <button className="btn btn-ghost" onClick={()=>setWinnerOpen(false)}>Close</button>
              <button className="btn btn-primary" onClick={()=>setWinnerOpen(false)}><Icon name="sparkle" size={14}/> Announce winner</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function WinnerRow({ w, idx, onUpdate, onRemove }){
  const [editing,setEditing] = useState(false);
  const [prize,setPrize] = useState(w.prize);
  const mins = Math.floor(w.timeLeftSec/60);
  const secs = w.timeLeftSec%60;
  const statusVariant = {
    "Present":"green",
    "Not Present":"amber",
    "Claimed":"violet",
    "Expired":"gray",
    "Forfeit":"pink",
  }[w.status] || "gray";

  return (
    <tr>
      <td><span className="badge badge-violet mono">#{w.ticket}</span></td>
      <td className="mono tx-cyan">{w.memberId}</td>
      <td className="mono tx-dim">{w.acct}</td>
      <td className="fw-6">{w.name}</td>
      <td className="tx-dim">{w.town}</td>
      <td>
        {editing ? (
          <div className="row gap-1">
            <input value={prize} onChange={(e)=>setPrize(e.target.value)} style={{background:"rgba(255,255,255,0.05)",border:"1px solid var(--glass-border)",borderRadius:8,padding:"4px 8px",color:"var(--text)",fontSize:12,width:160}}/>
            <button className="tool-btn" style={{width:26,height:26}} onClick={()=>{onUpdate({prize});setEditing(false)}}><Icon name="check" size={12} stroke={3}/></button>
          </div>
        ) : (
          <span className="row gap-2" style={{cursor:"pointer"}} onClick={()=>setEditing(true)}>
            <span className="fw-6" style={{fontSize:12.5}}>{w.prize}</span>
            <Icon name="settings" size={11} style={{color:"var(--text-mute)"}}/>
          </span>
        )}
      </td>
      <td><Check checked={w.claimed} onChange={(v)=>onUpdate({claimed:v,status:v?"Claimed":w.status})}/></td>
      <td className="mono tx-dim">{w.drawnAt}</td>
      <td><span className={"badge badge-"+statusVariant}><span className="dot"/>{w.status}</span></td>
      <td>
        {w.status==="Claimed" ? <span className="mono tx-mute">—</span> :
          w.timeLeftSec>0 ? (
            <span className="mono fw-7" style={{color: w.timeLeftSec<60 ? "#FFA6B0" : "#9CE9FF"}}>
              {String(mins).padStart(2,"0")}:{String(secs).padStart(2,"0")}
            </span>
          ) : <span className="mono tx-mute">Expired</span>
        }
      </td>
      <td>
        <div className="row gap-1">
          <button className="btn btn-ghost btn-sm" onClick={()=>onUpdate({timeLeftSec:300,status:"Present"})} title="Reset countdown"><Icon name="reset" size={11}/></button>
          <button className="btn btn-ghost btn-sm" onClick={()=>onUpdate({status:"Present",claimed:true})} style={{color:"#9FF0C8"}}>Valid</button>
          <button className="btn btn-ghost btn-sm" onClick={()=>onUpdate({status:"Not Present"})}>No Show</button>
          <button className="btn btn-ghost btn-sm" onClick={()=>onUpdate({status:"Forfeit",timeLeftSec:0})} style={{color:"#FFA6B0"}}>Forfeit</button>
        </div>
      </td>
    </tr>
  );
}

window.DrawPage = DrawPage;
