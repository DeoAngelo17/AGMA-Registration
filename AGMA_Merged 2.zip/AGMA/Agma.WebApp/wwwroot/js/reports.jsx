// ===== AGMA — Reports =====
function ReportsPage({ registrations, winners }){
  const toast = useToast();
  const [range, setRange] = useState("30D");

  const summary = window.AGMA_DATA.DAILY_SUMMARY;
  const days = range==="7D" ? 7 : range==="14D" ? 14 : 30;
  const data = summary.slice(-days);
  const maxV = Math.max(...data.map(d=>d.total));

  const venues = window.AGMA_DATA.VENUES.map(v=>({
    name:v.name,
    count: registrations.filter(r=>r.venue===v.name).length,
  })).sort((a,b)=>b.count-a.count);
  const maxVenue = Math.max(1, ...venues.map(v=>v.count));

  const seq = registrations.filter(r=>r.remarks==="Sequential").length;
  const sim = registrations.filter(r=>r.remarks==="Simultaneous").length;

  const doExport = (kind)=>{
    toast.info(`Compiling ${kind} report`, "Aggregating last 30 days · all venues · all coops");
    setTimeout(()=>toast.ok(`${kind} ready`, `AGMA-summary-2026-05-15.${kind.toLowerCase()==="pdf"?"pdf":"xlsx"} downloaded`), 1100);
  };

  return (
    <div className="fade-up">
      <PageHeader
        title="Reports & analytics"
        sub="Cross-venue rollups, daily summaries, and exportable audit views for the cooperative board."
        right={
          <>
            <button className="btn btn-ghost" onClick={()=>doExport("PDF")}><Icon name="doc"/> Export PDF</button>
            <button className="btn btn-ghost" onClick={()=>doExport("Excel")}><Icon name="download"/> Export Excel</button>
            <button className="btn btn-primary" onClick={()=>window.print()}><Icon name="printer"/> Print</button>
          </>
        }
      />

      {/* KPI strip */}
      <div className="stat-grid mb-5">
        <Stat icon="users"  variant="v" label="Total Registered (Today)" value={registrations.length.toLocaleString()} delta="+18% vs yesterday" up/>
        <Stat icon="ticket" variant="b" label="Tickets Issued (30D)" value="3,482" delta="Across 4 venues" />
        <Stat icon="trophy" variant="p" label="Prizes Awarded"    value={winners.filter(w=>w.claimed).length+" / "+winners.length}    delta="Claim rate stable" />
        <Stat icon="zap"    variant="g" label="Avg Wait (sec)"    value="42"   delta="-12% vs last assembly" up/>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1.4fr 1fr",gap:18,marginBottom:18}}>
        {/* Daily Trend */}
        <div className="chart-card">
          <div className="row between mb-4">
            <div>
              <div className="fw-7" style={{fontSize:15}}>Daily registration summary</div>
              <div className="tx-dim" style={{fontSize:12.5}}>Sequential vs Simultaneous registrations</div>
            </div>
            <div className="tabs">
              {["7D","14D","30D"].map(r=>(
                <span key={r} className={"tab"+(range===r?" active":"")} onClick={()=>setRange(r)}>{r}</span>
              ))}
            </div>
          </div>
          <BarChart data={data} maxV={maxV}/>
        </div>

        {/* Sequential / Simultaneous donut */}
        <div className="chart-card" style={{display:"flex",flexDirection:"column",gap:14}}>
          <div>
            <div className="fw-7" style={{fontSize:15}}>Registration type mix</div>
            <div className="tx-dim" style={{fontSize:12.5}}>Today's breakdown</div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:18}}>
            <Donut a={seq} b={sim} colorA="#6F88FC" colorB="#FF7582"/>
            <div className="col gap-3" style={{flex:1}}>
              <div className="row gap-3">
                <span style={{width:12,height:12,borderRadius:3,background:"#6F88FC"}}/>
                <div className="flex-1">
                  <div className="fw-7" style={{fontSize:13.5}}>Sequential</div>
                  <div className="tx-dim" style={{fontSize:11.5}}>{seq} registrations</div>
                </div>
                <div className="mono fw-7" style={{fontSize:14}}>{Math.round(seq/(seq+sim||1)*100)}%</div>
              </div>
              <div className="row gap-3">
                <span style={{width:12,height:12,borderRadius:3,background:"#FF7582"}}/>
                <div className="flex-1">
                  <div className="fw-7" style={{fontSize:13.5}}>Simultaneous</div>
                  <div className="tx-dim" style={{fontSize:11.5}}>{sim} registrations</div>
                </div>
                <div className="mono fw-7" style={{fontSize:14}}>{Math.round(sim/(seq+sim||1)*100)}%</div>
              </div>
              <div className="glass mt-2" style={{padding:10,borderRadius:10,fontSize:11.5,color:"var(--text-dim)"}}>
                <Icon name="info" size={12} stroke={2.2}/> Simultaneous regs typically take 1.4× longer to process at the desk.
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Venue load */}
      <div className="chart-card mb-5">
        <div className="row between mb-4">
          <div>
            <div className="fw-7" style={{fontSize:15}}>Registrations by venue</div>
            <div className="tx-dim" style={{fontSize:12.5}}>Today, across all 4 active venues</div>
          </div>
          <span className="badge badge-cyan"><span className="dot"/>Live</span>
        </div>
        <div className="col gap-3">
          {venues.map((v,i)=>(
            <div key={v.name}>
              <div className="row between">
                <div className="fw-6" style={{fontSize:13.5}}>{v.name}</div>
                <div className="mono tx-dim" style={{fontSize:12}}>{v.count} reg{v.count===1?"":"s"}</div>
              </div>
              <div className="pb mt-2" style={{height:8}}>
                <div className="fill" style={{
                  width:`${(v.count/maxVenue)*100}%`,
                  background: ["linear-gradient(90deg,#A163F7,#6F88FC)","linear-gradient(90deg,#6F88FC,#45E3FF)","linear-gradient(90deg,#45E3FF,#3DD68C)","linear-gradient(90deg,#FF7582,#A163F7)"][i%4],
                  animation:"none"
                }}/>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent activity table — audit log */}
      <div className="tbl-wrap">
        <div className="tbl-head">
          <div>
            <h3>Audit log · last 20 events</h3>
            <div className="sub">Full system activity is retained for 7 years per AGMA archival policy</div>
          </div>
          <span className="badge badge-gray"><Icon name="shield" size={10} stroke={2.4}/> Tamper-evident</span>
        </div>
        <div className="tbl-scroll">
          <table className="dt">
            <thead><tr>
              <th>Time</th>
              <th>Actor</th>
              <th>Event</th>
              <th>Subject</th>
              <th>Venue</th>
              <th style={{width:120}}>Outcome</th>
            </tr></thead>
            <tbody>
              {AUDIT_LOG.map((e,i)=>(
                <tr key={i}>
                  <td className="mono tx-dim">{e.time}</td>
                  <td className="row gap-2">
                    <div style={{width:24,height:24,borderRadius:50,background:"var(--grad-primary)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700}}>{e.who.slice(0,2).toUpperCase()}</div>
                    <span>{e.who}</span>
                  </td>
                  <td><span className={"badge badge-"+e.color}><span className="dot"/>{e.event}</span></td>
                  <td className="mono tx-cyan">{e.subject}</td>
                  <td className="tx-dim">{e.venue}</td>
                  <td><span className="badge badge-green">SUCCESS</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function BarChart({ data, maxV }){
  return (
    <div>
      <div style={{display:"flex",alignItems:"flex-end",gap:6,height:220,padding:"4px 0",borderBottom:"1px solid var(--line)"}}>
        {data.map((d,i)=>{
          const h = (d.total/maxV)*100;
          const hSim = (d.simultaneous/d.total)*100;
          return (
            <div key={i} className="bar-col" style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",height:"100%",justifyContent:"flex-end",position:"relative"}}>
              <div style={{width:"100%",position:"relative",height:`${h}%`,borderRadius:"6px 6px 0 0",background:"linear-gradient(180deg, rgba(111,136,252,0.9), rgba(161,99,247,0.6))",overflow:"hidden",transition:"all .2s"}}>
                <div style={{position:"absolute",left:0,right:0,bottom:0,height:`${hSim}%`,background:"linear-gradient(180deg, rgba(69,227,255,0.95), rgba(69,227,255,0.45))"}}/>
              </div>
            </div>
          );
        })}
      </div>
      <div className="row between mt-3">
        <div className="row gap-3">
          <span className="row gap-2 tx-dim" style={{fontSize:12}}><span style={{width:10,height:10,borderRadius:3,background:"linear-gradient(180deg,#6F88FC,#A163F7)"}}/>Sequential</span>
          <span className="row gap-2 tx-dim" style={{fontSize:12}}><span style={{width:10,height:10,borderRadius:3,background:"#45E3FF"}}/>Simultaneous</span>
        </div>
        <div className="tx-mute" style={{fontSize:11.5}}>{data[0].date} → {data[data.length-1].date}</div>
      </div>
    </div>
  );
}

function Donut({ a, b, colorA, colorB }){
  const total = a+b || 1;
  const r = 46, c = 2*Math.PI*r;
  const aPct = a/total;
  return (
    <svg width="160" height="160" viewBox="0 0 120 120">
      <circle cx="60" cy="60" r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="16"/>
      <circle cx="60" cy="60" r={r} fill="none" stroke={colorA} strokeWidth="16"
        strokeDasharray={`${aPct*c} ${c}`} transform="rotate(-90 60 60)" strokeLinecap="round"/>
      <circle cx="60" cy="60" r={r} fill="none" stroke={colorB} strokeWidth="16"
        strokeDasharray={`${(1-aPct)*c} ${c}`} strokeDashoffset={`-${aPct*c}`}
        transform="rotate(-90 60 60)" strokeLinecap="round"/>
      <text x="60" y="58" textAnchor="middle" fontWeight="800" fontSize="22" fill="#fff" style={{letterSpacing:"-.02em"}}>{a+b}</text>
      <text x="60" y="75" textAnchor="middle" fontSize="9" fill="rgba(255,255,255,0.55)" style={{textTransform:"uppercase",letterSpacing:".12em"}}>TOTAL</text>
    </svg>
  );
}

const AUDIT_LOG = [
  { time:"10:12 AM", who:"admin",   event:"Winner drawn",     color:"violet", subject:"#00006 · MEM-099644", venue:"Pavilion Hall A — Main" },
  { time:"10:05 AM", who:"admin",   event:"Winner drawn",     color:"violet", subject:"#00009 · MEM-100037", venue:"Cooperative Gymnasium" },
  { time:"09:54 AM", who:"clerk2",  event:"MCO registered",   color:"blue",   subject:"#00015 · MEM-100892", venue:"Pavilion Hall A — Main" },
  { time:"09:42 AM", who:"admin",   event:"Prize claimed",    color:"green",  subject:"#00003 · MEM-099244", venue:"Pavilion Hall B — Annex" },
  { time:"09:34 AM", who:"clerk1",  event:"MCO registered",   color:"blue",   subject:"#00014 · MEM-100702", venue:"Cooperative Gymnasium" },
  { time:"09:27 AM", who:"clerk3",  event:"MCO registered",   color:"pink",   subject:"#00013 · MEM-100599 (Sim.)", venue:"Pavilion Hall B — Annex" },
  { time:"09:13 AM", who:"clerk1",  event:"MCO registered",   color:"blue",   subject:"#00012 · MEM-100412", venue:"Open Grounds (Tent)" },
  { time:"09:08 AM", who:"admin",   event:"Multi-acct grouped",color:"amber",subject:"MEM-100245 (3 accts)", venue:"Pavilion Hall A — Main" },
  { time:"08:55 AM", who:"system",  event:"Doors opened",     color:"cyan",   subject:"Venue active",        venue:"All venues" },
  { time:"08:32 AM", who:"admin",   event:"Login",            color:"gray",   subject:"admin@batelec",       venue:"—" },
];

window.ReportsPage = ReportsPage;
