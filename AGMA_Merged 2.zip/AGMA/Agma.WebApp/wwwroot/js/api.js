// ===== AGMA — API Client =====
// Centralized fetch wrapper that talks to the real ASP.NET Core backend.
// All endpoints go through here so JWT tokens are auto-attached.

const API = {
  _token: null,

  setToken(token) {
    this._token = token;
    if (token) localStorage.setItem("agma_token", token);
    else localStorage.removeItem("agma_token");
  },

  getToken() {
    if (!this._token) this._token = localStorage.getItem("agma_token");
    return this._token;
  },

  clearToken() {
    this._token = null;
    localStorage.removeItem("agma_token");
  },

  async _fetch(url, options = {}) {
    const token = this.getToken();
    const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
    if (token) headers["Authorization"] = "Bearer " + token;

    const res = await fetch(url, { ...options, headers });

    // If 401, token expired — force re-login
    if (res.status === 401) {
      this.clearToken();
      window.dispatchEvent(new CustomEvent("agma:auth-expired"));
      throw new Error("Session expired. Please log in again.");
    }

    return res;
  },

  // ── Auth ──
  async login(username, password) {
    const res = await this._fetch("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (res.ok && data.success && data.token) {
      this.setToken(data.token);
    }
    return { ok: res.ok, data };
  },

  async logout() {
    try { await this._fetch("/api/auth/logout", { method: "POST" }); } catch (_) {}
    this.clearToken();
  },

  // ── MCO Search (EBDATA) ──
  async searchMCO(name) {
    const res = await this._fetch("/api/mco/search?name=" + encodeURIComponent(name));
    const data = await res.json();
    return { ok: res.ok, data };
  },

  async getMCO(membershipNo) {
    const res = await this._fetch("/api/mco/" + encodeURIComponent(membershipNo));
    const data = await res.json();
    return { ok: res.ok, data };
  },

  // ── Registration ──
  async register(payload) {
    const res = await this._fetch("/api/registration/register", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    return { ok: res.ok, data };
  },

  async getRegistrations(page = 1, pageSize = 50) {
    const res = await this._fetch(`/api/registration/all?page=${page}&pageSize=${pageSize}`);
    const data = await res.json();
    return { ok: res.ok, data };
  },

  async getRegistrationById(id) {
    const res = await this._fetch("/api/registration/" + id);
    const data = await res.json();
    return { ok: res.ok, data };
  },

  // ── Dashboard ──
  async getDashboard() {
    const res = await this._fetch("/api/dashboard");
    const data = await res.json();
    return { ok: res.ok, data };
  },

  // ── Reports ──
  async getDailySummary(date) {
    const qs = date ? "?date=" + date : "";
    const res = await this._fetch("/api/reports/daily-summary" + qs);
    const data = await res.json();
    return { ok: res.ok, data };
  },

  async getReportDetails(from, to) {
    const parts = [];
    if (from) parts.push("from=" + from);
    if (to) parts.push("to=" + to);
    const qs = parts.length ? "?" + parts.join("&") : "";
    const res = await this._fetch("/api/reports/details" + qs);
    const data = await res.json();
    return { ok: res.ok, data };
  },
};

window.API = API;
