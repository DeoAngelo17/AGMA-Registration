// ===== Shared components for AGMA =====
const { useState, useEffect, useRef, useMemo, useCallback, useContext, createContext } = React;

// ---------- Inline icon (Lucide-style minimal set) ----------
function Icon({ name, size=18, stroke=1.8, style }){
  const c = "currentColor";
  const sw = stroke;
  const props = { width:size, height:size, viewBox:"0 0 24 24", fill:"none", stroke:c, strokeWidth:sw, strokeLinecap:"round", strokeLinejoin:"round", style };
  switch(name){
    case "dashboard": return <svg {...props}><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>;
    case "search":    return <svg {...props}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>;
    case "list":      return <svg {...props}><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/></svg>;
    case "wheel":     return <svg {...props}><circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18M5 5l14 14M19 5 5 19"/></svg>;
    case "chart":     return <svg {...props}><path d="M3 3v18h18"/><path d="M7 14l3-3 4 4 6-7"/></svg>;
    case "logout":    return <svg {...props}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/></svg>;
    case "bell":      return <svg {...props}><path d="M6 8a6 6 0 0 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9Z"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>;
    case "settings":  return <svg {...props}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/></svg>;
    case "user":      return <svg {...props}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>;
    case "lock":      return <svg {...props}><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>;
    case "eye":       return <svg {...props}><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>;
    case "eye-off":   return <svg {...props}><path d="M1 1l22 22"/><path d="M10.6 5.1A10.4 10.4 0 0 1 12 5c6.5 0 10 7 10 7a17.3 17.3 0 0 1-3.2 4.2"/><path d="M6.6 6.6A17.3 17.3 0 0 0 2 12s3.5 7 10 7c2 0 3.7-.6 5.1-1.5"/><path d="M14.1 14.1a3 3 0 0 1-4.2-4.2"/></svg>;
    case "check":     return <svg {...props}><path d="m5 13 4 4L20 6"/></svg>;
    case "x":         return <svg {...props}><path d="M18 6 6 18M6 6l12 12"/></svg>;
    case "plus":      return <svg {...props}><path d="M12 5v14M5 12h14"/></svg>;
    case "chev-r":    return <svg {...props}><path d="m9 6 6 6-6 6"/></svg>;
    case "chev-d":    return <svg {...props}><path d="m6 9 6 6 6-6"/></svg>;
    case "chev-l":    return <svg {...props}><path d="m15 6-6 6 6 6"/></svg>;
    case "filter":    return <svg {...props}><path d="M3 5h18l-7 9v6l-4-2v-4Z"/></svg>;
    case "calendar":  return <svg {...props}><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>;
    case "download":  return <svg {...props}><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>;
    case "printer":   return <svg {...props}><path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="9" rx="2"/><rect x="7" y="15" width="10" height="6"/></svg>;
    case "info":      return <svg {...props}><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v5h1"/></svg>;
    case "trophy":    return <svg {...props}><path d="M7 4h10v4a5 5 0 0 1-10 0V4Z"/><path d="M7 4H4v2a3 3 0 0 0 3 3M17 4h3v2a3 3 0 0 1-3 3"/><path d="M9 21h6"/><path d="M12 14v7"/></svg>;
    case "sparkle":   return <svg {...props}><path d="M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2Z"/></svg>;
    case "ticket":    return <svg {...props}><path d="M3 8a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3a2 2 0 0 0 0-4Z"/><path d="M13 6v2M13 11v2M13 16v2"/></svg>;
    case "users":     return <svg {...props}><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0"/><circle cx="17" cy="9" r="3"/><path d="M22 19a5 5 0 0 0-6-4.9"/></svg>;
    case "play":      return <svg {...props} fill={c}><path d="M6 4l14 8-14 8z" stroke="none"/></svg>;
    case "pause":     return <svg {...props}><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>;
    case "reset":     return <svg {...props}><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>;
    case "zap":       return <svg {...props}><path d="M13 2 4 14h7l-1 8 9-12h-7Z"/></svg>;
    case "loc":       return <svg {...props}><path d="M12 22s8-7 8-13a8 8 0 1 0-16 0c0 6 8 13 8 13Z"/><circle cx="12" cy="9" r="3"/></svg>;
    case "menu":      return <svg {...props}><path d="M4 6h16M4 12h16M4 18h16"/></svg>;
    case "doc":       return <svg {...props}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg>;
    case "warn":      return <svg {...props}><path d="M10.3 3.7 2 18a2 2 0 0 0 1.7 3h16.6A2 2 0 0 0 22 18L13.7 3.7a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></svg>;
    case "shield":    return <svg {...props}><path d="M12 2 4 5v6c0 5 4 9 8 11 4-2 8-6 8-11V5Z"/></svg>;
    default: return null;
  }
}

// ---------- Checkbox ----------
function Check({ checked, onChange, size=18 }){
  return (
    <span className={"chk"+(checked?" checked":"")} style={{width:size,height:size}} onClick={(e)=>{e.stopPropagation();onChange&&onChange(!checked)}}>
      <Icon name="check" size={size-6} stroke={3}/>
    </span>
  );
}

// ---------- Toast system ----------
const ToastCtx = createContext(null);
function ToastProvider({ children }){
  const [items,setItems] = useState([]);
  const push = useCallback((t)=>{
    const id = Math.random().toString(36).slice(2);
    setItems((x)=>[...x,{id, kind:"info", ...t}]);
    setTimeout(()=>setItems((x)=>x.filter(i=>i.id!==id)), t.duration||3800);
  },[]);
  const api = useMemo(()=>({
    ok:(title,message,opts={})=>push({kind:"ok",title,message,...opts}),
    err:(title,message,opts={})=>push({kind:"err",title,message,...opts}),
    info:(title,message,opts={})=>push({kind:"info",title,message,...opts}),
  }),[push]);
  return (
    <ToastCtx.Provider value={api}>
      {children}
      <div className="toast-host">
        {items.map(t=>(
          <div key={t.id} className={"toast "+t.kind}>
            <span className="ic">
              <Icon name={t.kind==="ok"?"check":t.kind==="err"?"warn":"info"} size={15} stroke={2.4}/>
            </span>
            <div style={{minWidth:0,flex:1}}>
              <div className="tt">{t.title}</div>
              {t.message && <div className="ms">{t.message}</div>}
            </div>
            <button className="x" onClick={()=>setItems((x)=>x.filter(i=>i.id!==t.id))}>✕</button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
const useToast = ()=>useContext(ToastCtx);

// ---------- Modal ----------
function Modal({ open, onClose, children, width=520 }){
  if(!open) return null;
  return (
    <div className="modal-mask" onClick={onClose}>
      <div className="modal" style={{maxWidth:width}} onClick={(e)=>e.stopPropagation()}>{children}</div>
    </div>
  );
}

// ---------- Sidebar ----------
const NAV = [
  { id:"dashboard", label:"Dashboard",            icon:"dashboard" },
  { id:"search",    label:"Search / Register",    icon:"search", hot:true },
  { id:"records",   label:"Registration Records", icon:"list" },
  { id:"draw",      label:"Draw Winners",         icon:"wheel" },
  { id:"reports",   label:"Reports",              icon:"chart" },
];

function Sidebar({ page, setPage, onLogout }){
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">A</div>
        <div>
          <div className="brand-name">AGMA 2026</div>
          <div className="brand-sub">Membership Assembly</div>
        </div>
      </div>

      <div className="nav-section-title">Main</div>
      {NAV.map(n=>(
        <div key={n.id} className={"nav-item"+(page===n.id?" active":"")} onClick={()=>setPage(n.id)}>
          <span className="nav-icon"><Icon name={n.icon}/></span>
          <span>{n.label}</span>
          {n.hot && <span className="nav-badge">LIVE</span>}
        </div>
      ))}

      <div className="nav-section-title mt-4">Workspace</div>
      <div className="nav-item">
        <span className="nav-icon"><Icon name="users"/></span>
        <span>Members</span>
      </div>
      <div className="nav-item">
        <span className="nav-icon"><Icon name="settings"/></span>
        <span>Settings</span>
      </div>

      <div className="sidebar-foot">
        <div className="glass" style={{padding:"12px 14px",borderRadius:14,display:"flex",gap:10,alignItems:"center"}}>
          <div className="stat-icon b" style={{width:34,height:34,fontSize:14}}><Icon name="zap" size={16}/></div>
          <div style={{minWidth:0,flex:1}}>
            <div className="fw-7" style={{fontSize:12.5}}>BATELEC II</div>
            <div className="tx-mute" style={{fontSize:10.5,textTransform:"uppercase",letterSpacing:".08em"}}>Coop · Active</div>
          </div>
        </div>
        <div className="nav-item mt-3" onClick={onLogout}>
          <span className="nav-icon"><Icon name="logout"/></span>
          <span>Logout</span>
        </div>
      </div>
    </aside>
  );
}

// ---------- Topbar ----------
function Topbar({ crumbs=[], user }){
  return (
    <header className="topbar">
      <div className="crumbs">
        {crumbs.map((c,i)=>(
          <React.Fragment key={i}>
            {i>0 && <Icon name="chev-r" size={13} stroke={2} style={{opacity:.4}}/>}
            <span className={i===crumbs.length-1?"current":""}>{c}</span>
          </React.Fragment>
        ))}
      </div>
      <div className="topbar-search">
        <Icon name="search" size={15}/>
        <span>Quick find — members, tickets, accounts…</span>
        <span className="mono" style={{marginLeft:"auto",fontSize:11,color:"var(--text-mute)",border:"1px solid var(--glass-border)",padding:"2px 6px",borderRadius:6}}>⌘K</span>
      </div>
      <div className="topbar-tools">
        <button className="tool-btn"><Icon name="bell"/><span className="pip"/></button>
        <button className="tool-btn"><Icon name="settings"/></button>
        <div className="user-chip">
          <div className="av">{user?.initials||"AD"}</div>
          <div>
            <div className="nm">{user?.name||"Admin"}</div>
            <div className="rl">{user?.role||"Coop Administrator"}</div>
          </div>
        </div>
      </div>
    </header>
  );
}

// ---------- Page header ----------
function PageHeader({ title, sub, right }){
  return (
    <div className="page-header">
      <div>
        <h1 className="page-title">{title}</h1>
        {sub && <p className="page-sub">{sub}</p>}
      </div>
      {right && <div className="row gap-3">{right}</div>}
    </div>
  );
}

// ---------- Confetti burst ----------
function Confetti({ active, count=80 }){
  if(!active) return null;
  const colors = ["#A163F7","#6F88FC","#45E3FF","#FF7582","#FFB547","#3DD68C"];
  const pieces = Array.from({length:count}).map((_,i)=>({
    left: Math.random()*100,
    delay: Math.random()*0.4,
    color: colors[i%colors.length],
    rot: Math.random()*360,
    dur: 1.6+Math.random()*1.4,
  }));
  return (
    <div style={{position:"fixed",inset:0,pointerEvents:"none",zIndex:300,overflow:"hidden"}}>
      {pieces.map((p,i)=>(
        <span key={i} className="confetti" style={{
          left:`${p.left}%`, background:p.color, transform:`rotate(${p.rot}deg)`,
          animationDelay:`${p.delay}s`, animationDuration:`${p.dur}s`,
        }}/>
      ))}
    </div>
  );
}

// Expose
Object.assign(window, { Icon, Check, ToastProvider, useToast, Modal, Sidebar, Topbar, PageHeader, Confetti, NAV });
