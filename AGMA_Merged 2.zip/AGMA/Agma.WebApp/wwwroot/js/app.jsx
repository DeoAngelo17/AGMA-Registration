// ===== AGMA — Main App Router (wired to real API) =====
function App(){
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [registrations, setRegistrations] = useState([]);
  const [winners, setWinners] = useState([]);

  // On login, fetch registrations from the backend
  const handleLogin = (u) => {
    setUser(u);
    // Load existing registrations from AGMADB
    API.getRegistrations(1, 200).then(r => {
      if(r.ok && r.data.data) setRegistrations(r.data.data);
    }).catch(()=>{});
  };

  const handleLogout = () => {
    API.logout();
    setUser(null);
    setRegistrations([]);
    setWinners([]);
    setPage("dashboard");
  };

  // Listen for auth expiration (401 from API)
  useEffect(()=>{
    const handler = () => {
      setUser(null);
      setRegistrations([]);
    };
    window.addEventListener("agma:auth-expired", handler);
    return ()=> window.removeEventListener("agma:auth-expired", handler);
  },[]);

  // Listen for cross-page nav requests
  useEffect(()=>{
    const h = (e)=>setPage(e.detail);
    window.addEventListener("agma:nav", h);
    return ()=>window.removeEventListener("agma:nav", h);
  },[]);

  // Auto-login if token exists in storage
  useEffect(()=>{
    const token = API.getToken();
    if(token){
      // Validate by calling dashboard
      API.getDashboard().then(r => {
        if(r.ok){
          setUser({ name:"Administrator", initials:"AD", role:"Admin", username:"admin" });
          API.getRegistrations(1, 200).then(rr => {
            if(rr.ok && rr.data.data) setRegistrations(rr.data.data);
          });
        } else {
          API.clearToken();
        }
      }).catch(()=> API.clearToken());
    }
  },[]);

  if(!user){
    return <LoginPage onLogin={handleLogin}/>;
  }

  const crumbsMap = {
    dashboard: ["AGMA 2026", "Dashboard"],
    search:    ["AGMA 2026", "Operations", "Search & Register"],
    records:   ["AGMA 2026", "Operations", "Registration Records"],
    draw:      ["AGMA 2026", "Operations", "Draw Winners"],
    reports:   ["AGMA 2026", "Analytics", "Reports"],
  };

  return (
    <>
      <div className="app-bg"/>
      <div className="grid-overlay"/>
      <div className="app-shell">
        <Sidebar page={page} setPage={setPage} onLogout={handleLogout}/>
        <main className="main">
          <Topbar crumbs={crumbsMap[page]} user={user}/>
          <div className="page" key={page}>
            {page==="dashboard" && <Dashboard goto={setPage} registrations={registrations} winners={winners}/>}
            {page==="search"    && <SearchPage registrations={registrations} setRegistrations={setRegistrations}/>}
            {page==="records"   && <RecordsPage registrations={registrations}/>}
            {page==="draw"      && <DrawPage registrations={registrations} winners={winners} setWinners={setWinners}/>}
            {page==="reports"   && <ReportsPage registrations={registrations} winners={winners}/>}
          </div>
        </main>
      </div>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<ToastProvider><App/></ToastProvider>);
