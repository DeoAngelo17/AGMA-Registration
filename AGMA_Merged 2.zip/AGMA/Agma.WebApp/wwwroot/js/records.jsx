// ===== AGMA — Registration Records (wired to real API) =====
function RecordsPage({ registrations }){
  const toast = useToast();
  const [q, setQ] = useState("");
  const [remarksFilter, setRemarksFilter] = useState("All");
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const filtered = useMemo(()=>{
    return registrations.filter(r=>{
      if(remarksFilter!=="All" && r.remarks!==remarksFilter) return false;
      if(q){
        const s = q.toLowerCase();
        const membership = (r.membershipNo || r.memberId || "").toLowerCase();
        const ticket = (r.ticketNo || r.ticket || "").toLowerCase();
        const names = (r.accountNameOfMCO || (r.names ? r.names.join(", ") : "")).toLowerCase();
        const accts = (r.accountNo || (r.accts ? r.accts.join(", ") : "")).toLowerCase();
        if(!membership.includes(s) && !ticket.includes(s) && !names.includes(s) && !accts.includes(s)) return false;
      }
      return true;
    });
  },[registrations, q, remarksFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length/pageSize));
  const view = filtered.slice((page-1)*pageSize, page*pageSize);
  useEffect(()=>{ if(page>totalPages) setPage(1); },[totalPages,page]);

  return (
    <div className="fade-up">
      <PageHeader
        title="Registration records"
        sub="Full audit log of every MCO registered through the AGMA console — data from AGMADB."
      />

      {/* Filter bar */}
      <div className="glass mb-5" style={{padding:18,borderRadius:18}}>
        <div className="row between mb-4">
          <div className="row gap-2">
            <div className="stat-icon v" style={{width:34,height:34,fontSize:13}}><Icon name="filter" size={14}/></div>
            <div>
              <div className="fw-7" style={{fontSize:14}}>Filters</div>
              <div className="tx-dim" style={{fontSize:12}}>Search or filter the registration records</div>
            </div>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={()=>{ setQ(""); setRemarksFilter("All"); }}>
            <Icon name="reset" size={13}/> Reset
          </button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:12}}>
          <div>
            <div className="field-label">Search</div>
            <div className="field">
              <span className="field-icon"><Icon name="search" size={15}/></span>
              <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Ticket, name, membership #, account…"/>
            </div>
          </div>
          <div>
            <div className="field-label">Remarks</div>
            <div className="field">
              <span className="field-icon"><Icon name="ticket" size={15}/></span>
              <select value={remarksFilter} onChange={(e)=>setRemarksFilter(e.target.value)}>
                <option>All</option>
                <option>Sequential</option>
                <option>Simultaneous</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Summary stats */}
      <div className="stat-grid mb-5" style={{gridTemplateColumns:"repeat(3,1fr)"}}>
        <MiniStat label="Filtered" value={filtered.length} sub={`of ${registrations.length} total`} variant="v" icon="list"/>
        <MiniStat label="Sequential" value={filtered.filter(r=>r.remarks==="Sequential").length} sub="single-account regs" variant="b" icon="ticket"/>
        <MiniStat label="Simultaneous" value={filtered.filter(r=>r.remarks==="Simultaneous").length} sub="multi-account groups" variant="p" icon="users"/>
      </div>

      {/* Records table */}
      <div className="tbl-wrap">
        <div className="tbl-head">
          <div>
            <h3>All registrations</h3>
            <div className="sub">{filtered.length} record{filtered.length===1?"":"s"} from AGMADB</div>
          </div>
        </div>
        <div className="tbl-scroll">
          <table className="dt">
            <thead><tr>
              <th style={{width:50}}>No.</th>
              <th>Ticket No.</th>
              <th>Membership No.</th>
              <th>Account Name of MCO</th>
              <th>Account No.</th>
              <th>Date</th>
              <th>Time</th>
              <th>Venue</th>
              <th>Remarks</th>
            </tr></thead>
            <tbody>
              {view.length===0 && (
                <tr><td colSpan={9}>
                  <div className="empty">
                    <div className="empty-ic"><Icon name="search" size={26}/></div>
                    <h4>No records match</h4>
                    <p>Try widening your search or clearing filters.</p>
                  </div>
                </td></tr>
              )}
              {view.map((r,i)=>(
                <tr key={r.no || r.ticketNo || i}>
                  <td className="mono tx-mute">{r.no || ((page-1)*pageSize + i + 1)}</td>
                  <td><span className="badge badge-violet mono">#{r.ticketNo || r.ticket}</span></td>
                  <td className="mono tx-cyan fw-6">{r.membershipNo || r.memberId}</td>
                  <td style={{maxWidth:260}}>
                    <div style={{whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>
                      {r.accountNameOfMCO || (r.names ? r.names.join(", ") : "")}
                    </div>
                  </td>
                  <td style={{maxWidth:200}}>
                    <div className="mono tx-dim" style={{fontSize:11.5,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>
                      {r.accountNo || (r.accts ? r.accts.join(", ") : "")}
                    </div>
                  </td>
                  <td className="mono tx-dim">{r.date}</td>
                  <td className="mono tx-dim">{r.timeOfRegistration || r.time}</td>
                  <td className="tx-dim">{r.venue}</td>
                  <td><span className={"badge "+(r.remarks==="Sequential"?"badge-blue":"badge-pink")}><span className="dot"/>{r.remarks}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length > 0 && (
          <div className="tbl-foot">
            <span>Showing {(page-1)*pageSize+1}–{Math.min(page*pageSize,filtered.length)} of {filtered.length}</span>
            <div className="pgr">
              <span className="pg" onClick={()=>setPage(p=>Math.max(1,p-1))}><Icon name="chev-l" size={12}/></span>
              {Array.from({length:totalPages}).map((_,i)=>(
                <span key={i} className={"pg"+(page===i+1?" active":"")} onClick={()=>setPage(i+1)}>{i+1}</span>
              ))}
              <span className="pg" onClick={()=>setPage(p=>Math.min(totalPages,p+1))}><Icon name="chev-r" size={12}/></span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function MiniStat({ label, value, sub, variant, icon }){
  return (
    <div className="stat" style={{padding:18}}>
      <div className="stat-head">
        <div className={"stat-icon "+variant} style={{width:34,height:34}}><Icon name={icon} size={15}/></div>
        <div className="badge badge-gray" style={{fontSize:10}}>{label.toUpperCase()}</div>
      </div>
      <div className="stat-value" style={{fontSize:24,marginTop:8}}>{value}</div>
      <div className="stat-trend">{sub}</div>
    </div>
  );
}

window.RecordsPage = RecordsPage;
