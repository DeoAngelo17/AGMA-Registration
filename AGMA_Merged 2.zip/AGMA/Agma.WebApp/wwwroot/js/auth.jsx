// ===== AGMA — Login page (wired to real API) =====
function LoginPage({ onLogin }){
  const [user,setUser] = useState("");
  const [pass,setPass] = useState("");
  const [show,setShow] = useState(false);
  const [remember,setRemember] = useState(true);
  const [loading,setLoading] = useState(false);
  const [shake,setShake] = useState(false);
  const toast = useToast();

  const submit = async (e)=>{
    e && e.preventDefault();
    if(!user || !pass){
      setShake(true);setTimeout(()=>setShake(false),500);
      toast.err("Missing credentials","Please enter both username and password.");
      return;
    }
    setLoading(true);
    try {
      const { ok, data } = await API.login(user.trim(), pass);
      if(ok && data.success){
        toast.ok("Welcome back", `Signed in as ${data.fullName}.`);
        onLogin({
          name: data.fullName,
          initials: data.fullName.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase(),
          role: data.role,
          username: user.trim(),
        });
      } else {
        setShake(true); setTimeout(()=>setShake(false),500);
        toast.err("Authentication failed", data.message || "Invalid username or password.");
      }
    } catch(err) {
      setShake(true); setTimeout(()=>setShake(false),500);
      toast.err("Connection error", "Could not reach the server. Check your connection.");
      console.error("Login error:", err);
    } finally {
      setLoading(false);
    }
  };

  const particles = useMemo(()=>Array.from({length:36}).map((_,i)=>({
    left: Math.random()*100, size: 3+Math.random()*7,
    dur: 14+Math.random()*22, delay: -Math.random()*30,
    dx: (Math.random()-0.5)*120 + "px", op: 0.3+Math.random()*0.5,
  })),[]);

  return (
    <>
      <div className="app-bg"/><div className="grid-overlay"/>
      <div className="particles">
        {particles.map((p,i)=>(<span key={i} className="particle" style={{left:`${p.left}%`,bottom:"-20px",width:p.size,height:p.size,animationDuration:`${p.dur}s`,animationDelay:`${p.delay}s`,opacity:p.op,["--dx"]:p.dx}}/>))}
      </div>
      <div className="login-stage">
        <div style={{display:"grid",gridTemplateColumns:"1.1fr 1fr",gap:48,alignItems:"center",width:"min(1080px,100%)"}}>
          <div className="login-side" style={{padding:"0 8px"}}>
            <div className="row gap-3 mb-5">
              <div className="brand-mark float" style={{width:54,height:54,fontSize:22,borderRadius:14}}>A</div>
              <div>
                <div className="fw-8" style={{fontSize:18,letterSpacing:"-.01em"}}>AGMA 2026</div>
                <div className="tx-mute" style={{fontSize:12,letterSpacing:".12em",textTransform:"uppercase"}}>Annual Membership Assembly</div>
              </div>
            </div>
            <h1 style={{fontSize:44,fontWeight:800,letterSpacing:"-.025em",lineHeight:1.05,margin:0}}>
              The check-in console <br/>for <span style={{background:"var(--grad-aurora)",WebkitBackgroundClip:"text",backgroundClip:"text",color:"transparent"}}>cooperative membership.</span>
            </h1>
            <p className="tx-dim mt-4" style={{fontSize:15.5,maxWidth:440,lineHeight:1.6}}>
              Register MCOs, group multi-account households, run the prize draw, and export verifiable reports — all from one unified workspace.
            </p>
            <div className="row gap-3 mt-5" style={{flexWrap:"wrap"}}>
              <span className="badge badge-violet"><span className="dot"/>Live registration system</span>
              <span className="badge badge-cyan"><span className="dot"/>Connected to AGMADB</span>
            </div>
          </div>
          <div className={"login-card"+(shake?" shake":"")} style={{animation: shake?"shake .5s":"fade-up .5s ease both"}}>
            <div className="row gap-3 mb-4">
              <div className="brand-mark">A</div>
              <div>
                <div className="fw-8" style={{fontSize:17}}>Sign in</div>
                <div className="tx-mute" style={{fontSize:12.5}}>Use your cooperative admin credentials</div>
              </div>
            </div>
            <form onSubmit={submit}>
              <div>
                <div className="field-label">Username</div>
                <div className="field">
                  <span className="field-icon"><Icon name="user" size={17}/></span>
                  <input value={user} onChange={(e)=>setUser(e.target.value)} placeholder="e.g. admin" autoComplete="username"/>
                </div>
              </div>
              <div className="mt-4">
                <div className="field-label">Password</div>
                <div className="field">
                  <span className="field-icon"><Icon name="lock" size={17}/></span>
                  <input type={show?"text":"password"} value={pass} onChange={(e)=>setPass(e.target.value)} placeholder="••••••••" autoComplete="current-password"/>
                  <button type="button" onClick={()=>setShow(s=>!s)} className="field-icon" style={{background:"none",border:"none",cursor:"pointer"}}>
                    <Icon name={show?"eye-off":"eye"} size={17}/>
                  </button>
                </div>
              </div>
              <div className="row between mt-4">
                <label className="row gap-2" style={{cursor:"pointer"}} onClick={()=>setRemember(r=>!r)}>
                  <Check checked={remember} onChange={setRemember} size={17}/>
                  <span className="tx-dim" style={{fontSize:13}}>Remember this device</span>
                </label>
              </div>
              <button type="submit" className="btn btn-primary btn-lg mt-5" style={{width:"100%"}} disabled={loading}>
                {loading ? <><span className="spinner"/> Signing in…</> : <>Sign in to AGMA <Icon name="chev-r" size={16}/></>}
              </button>
              <div className="row mt-4" style={{gap:10,alignItems:"center"}}>
                <div style={{flex:1,height:1,background:"var(--line)"}}/>
                <span className="tx-mute" style={{fontSize:11.5,letterSpacing:".12em",textTransform:"uppercase"}}>Secure access</span>
                <div style={{flex:1,height:1,background:"var(--line)"}}/>
              </div>
              <div className="row gap-3 mt-3" style={{justifyContent:"center"}}>
                <span className="badge badge-gray"><Icon name="shield" size={11} stroke={2.4}/> JWT Auth</span>
                <span className="badge badge-gray"><Icon name="lock" size={11} stroke={2.4}/> PBKDF2-SHA512</span>
              </div>
            </form>
          </div>
        </div>
        <div style={{position:"absolute",bottom:18,left:0,right:0,display:"flex",justifyContent:"center",fontSize:11.5,color:"var(--text-mute)",letterSpacing:".06em"}}>
          AGMA 2026 · v2.4.1 · © Cooperative Information Services
        </div>
      </div>
      <style>{`@keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-8px)}40%,80%{transform:translateX(8px)}}`}</style>
    </>
  );
}
window.LoginPage = LoginPage;
