using Microsoft.AspNetCore.Mvc.Filters;

namespace Agma.WebApp.Filters;

/// <summary>
/// Action filter that logs entry and exit of controller actions for auditing.
/// </summary>
public class AuditActionFilter : IAsyncActionFilter
{
    private readonly ILogger<AuditActionFilter> _logger;

    public AuditActionFilter(ILogger<AuditActionFilter> logger)
    {
        _logger = logger;
    }

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var controller = context.Controller.GetType().Name;
        var action = context.ActionDescriptor.DisplayName;
        var user = context.HttpContext.User.Identity?.Name ?? "Anonymous";
        var ip = context.HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";

        _logger.LogInformation(
            "[AUDIT] User: {User} | IP: {IP} | Action: {Controller}.{Action}",
            user, ip, controller, action);

        var result = await next();

        if (result.Exception is not null)
        {
            _logger.LogWarning(
                "[AUDIT] Action FAILED: {Controller}.{Action} | User: {User} | Error: {Error}",
                controller, action, user, result.Exception.Message);
        }
    }
}
