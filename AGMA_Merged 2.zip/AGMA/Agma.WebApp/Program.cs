using Agma.WebApp;
using Agma.WebApp.Filters;
using Agma.WebApp.Middleware;
using Microsoft.AspNetCore.StaticFiles;
using Serilog;

// ── Serilog bootstrap ──
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .CreateBootstrapLogger();

try
{
    Log.Information("Starting AGMA Web Application...");

    var builder = WebApplication.CreateBuilder(args);

    // ── Serilog (replaces default logging) ──
    builder.Host.UseSerilog((context, services, configuration) =>
        configuration.ReadFrom.Configuration(context.Configuration));

    // ── Controllers + JSON options ──
    builder.Services.AddControllers(options =>
    {
        options.Filters.Add<AuditActionFilter>();
    })
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
    });

    // ── Register all AGMA services via DI extension ──
    builder.Services.AddAgmaServices(builder.Configuration);

    // ── Swagger (development only) ──
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen(options =>
    {
        options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
        {
            Title = "AGMA API",
            Version = "v1",
            Description = "Annual General Membership Assembly — Registration System API"
        });

        // JWT auth header in Swagger
        options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
        {
            Name = "Authorization",
            Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
            Scheme = "Bearer",
            BearerFormat = "JWT",
            In = Microsoft.OpenApi.Models.ParameterLocation.Header,
            Description = "Enter your JWT token"
        });

        options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
        {
            {
                new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                {
                    Reference = new Microsoft.OpenApi.Models.OpenApiReference
                    {
                        Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    }
                },
                Array.Empty<string>()
            }
        });
    });

    // ── CORS (adjust for production) ──
    builder.Services.AddCors(options =>
    {
        options.AddPolicy("AllowAll", policy =>
            policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
    });

    // ============================================================
    // BUILD
    // ============================================================
    var app = builder.Build();

    // ── Middleware pipeline ──
    app.UseMiddleware<ExceptionMiddleware>();

    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "AGMA API v1"));
    }

    app.UseSerilogRequestLogging();

    app.UseCors("AllowAll");

    // ── Serve the frontend from wwwroot ──
    app.UseDefaultFiles();

    // Custom MIME type for .jsx files (Babel transpiles them in the browser)
    var mimeProvider = new FileExtensionContentTypeProvider();
    mimeProvider.Mappings[".jsx"] = "application/javascript";
    app.UseStaticFiles(new StaticFileOptions
    {
        ContentTypeProvider = mimeProvider
    });

    app.UseAuthentication();
    app.UseMiddleware<JwtMiddleware>();
    app.UseAuthorization();

    app.MapControllers();

    // ── Fallback: non-API, non-file requests serve index.html (SPA) ──
    app.MapFallbackToFile("index.html");

    // ── Seed default admin user on first run ──
    await SeedDefaultAdmin(app);

    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Application terminated unexpectedly.");
}
finally
{
    Log.CloseAndFlush();
}

// ── Seed helper ──
static async Task SeedDefaultAdmin(WebApplication app)
{
    using var scope = app.Services.CreateScope();
    var authService = scope.ServiceProvider.GetRequiredService<Agma.Service.Interfaces.IAuthService>();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();

    try
    {
        var created = await authService.CreateUserAsync(
            username: "admin",
            password: "Admin@123",
            fullName: "System Administrator",
            email: "admin@agma.local",
            roleId: 1 // Admin role
        );

        if (created)
            logger.LogInformation("Default admin user seeded: admin / Admin@123");
        else
            logger.LogDebug("Default admin user already exists — skipping seed.");
    }
    catch (Exception ex)
    {
        logger.LogWarning(ex, "Could not seed default admin user (tables may not exist yet).");
    }
}
