using Agma.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agma.WebApp.Controllers;

/// <summary>
/// Dedicated MCO search endpoint: GET /api/mco/search?name=
/// Searches the EBDATA read-only database.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class MCOController : ControllerBase
{
    private readonly IEBDataService _ebDataService;

    public MCOController(IEBDataService ebDataService)
    {
        _ebDataService = ebDataService;
    }

    /// <summary>
    /// GET /api/mco/search?name={name}
    /// Search MCO by name across EBDATA (MEMPROF + CON_MASTER).
    /// Returns grouped results: 1 membership → N accounts.
    /// </summary>
    [HttpGet("search")]
    public async Task<IActionResult> Search([FromQuery] string name, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Trim().Length < 2)
        {
            return BadRequest(new
            {
                Success = false,
                Message = "Search term must be at least 2 characters."
            });
        }

        var results = await _ebDataService.SearchMCOAsync(name, ct);

        return Ok(new
        {
            Success = true,
            TotalResults = results.Count(),
            Data = results
        });
    }

    /// <summary>
    /// GET /api/mco/{membershipNo}
    /// Get MCO details by membership number.
    /// </summary>
    [HttpGet("{membershipNo}")]
    public async Task<IActionResult> GetByMembershipNo(string membershipNo, CancellationToken ct)
    {
        var result = await _ebDataService.GetMCOByMembershipNoAsync(membershipNo, ct);

        if (result is null)
            return NotFound(new { Success = false, Message = "Membership number not found in EBDATA." });

        return Ok(new { Success = true, Data = result });
    }
}
