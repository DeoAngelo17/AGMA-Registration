using Agma.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agma.WebApp.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ReportsController : ControllerBase
{
    private readonly IReportService _reportService;

    public ReportsController(IReportService reportService)
    {
        _reportService = reportService;
    }

    /// <summary>
    /// GET /api/reports/daily-summary?date=2026-05-14
    /// Returns daily registration summary grouped by venue and remarks.
    /// </summary>
    [HttpGet("daily-summary")]
    public async Task<IActionResult> GetDailySummary([FromQuery] string? date, CancellationToken ct)
    {
        DateOnly? parsedDate = null;
        if (!string.IsNullOrWhiteSpace(date) && DateOnly.TryParse(date, out var d))
            parsedDate = d;

        var results = await _reportService.GetDailySummaryAsync(parsedDate, ct);
        return Ok(new { Success = true, Data = results });
    }

    /// <summary>
    /// GET /api/reports/details?from=2026-05-01&to=2026-05-14
    /// Returns detailed registration records within a date range.
    /// </summary>
    [HttpGet("details")]
    public async Task<IActionResult> GetDetails(
        [FromQuery] string? from,
        [FromQuery] string? to,
        CancellationToken ct)
    {
        DateOnly? dateFrom = null, dateTo = null;

        if (!string.IsNullOrWhiteSpace(from) && DateOnly.TryParse(from, out var f))
            dateFrom = f;
        if (!string.IsNullOrWhiteSpace(to) && DateOnly.TryParse(to, out var t))
            dateTo = t;

        var results = await _reportService.GetRegistrationDetailsAsync(dateFrom, dateTo, ct);
        return Ok(new { Success = true, Data = results });
    }
}
