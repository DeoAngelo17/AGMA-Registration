using System.Security.Claims;
using Agma.Service.DTOs.Registration;
using Agma.Service.Interfaces;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agma.WebApp.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class RegistrationController : ControllerBase
{
    private readonly IAGMARegistrationService _registrationService;
    private readonly IEBDataService _ebDataService;
    private readonly IValidator<RegisterAGMARequestDto> _registerValidator;

    public RegistrationController(
        IAGMARegistrationService registrationService,
        IEBDataService ebDataService,
        IValidator<RegisterAGMARequestDto> registerValidator)
    {
        _registrationService = registrationService;
        _ebDataService = ebDataService;
        _registerValidator = registerValidator;
    }

    /// <summary>
    /// GET /api/registration/search?name={name}
    /// Search EBDATA for MCO by name. Returns grouped results.
    /// </summary>
    [HttpGet("search")]
    public async Task<IActionResult> SearchMCO([FromQuery] string name, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Trim().Length < 2)
        {
            return BadRequest(new { Success = false, Message = "Search term must be at least 2 characters." });
        }

        var results = await _ebDataService.SearchMCOAsync(name, ct);
        return Ok(new { Success = true, Data = results });
    }

    /// <summary>
    /// GET /api/registration/mco/{membershipNo}
    /// Get a specific MCO by membership number from EBDATA.
    /// </summary>
    [HttpGet("mco/{membershipNo}")]
    public async Task<IActionResult> GetMCO(string membershipNo, CancellationToken ct)
    {
        var result = await _ebDataService.GetMCOByMembershipNoAsync(membershipNo, ct);
        if (result is null)
            return NotFound(new { Success = false, Message = "Membership number not found." });

        return Ok(new { Success = true, Data = result });
    }

    /// <summary>
    /// POST /api/registration/register
    /// Register an MCO for the AGMA event.
    /// </summary>
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterAGMARequestDto request, CancellationToken ct)
    {
        var validation = await _registerValidator.ValidateAsync(request, ct);
        if (!validation.IsValid)
        {
            return BadRequest(new
            {
                Success = false,
                Errors = validation.Errors.Select(e => e.ErrorMessage)
            });
        }

        // Get the authenticated user's username for the RegisteredBy field
        var registeredBy = User.FindFirst(ClaimTypes.Name)?.Value
                        ?? User.FindFirst("fullName")?.Value
                        ?? "unknown";

        var result = await _registrationService.RegisterAsync(request, registeredBy, ct);

        if (!result.Success)
            return Conflict(result);

        return CreatedAtAction(
            nameof(GetById),
            new { id = result.No },
            result
        );
    }

    /// <summary>
    /// GET /api/registration/all?page=1&pageSize=50
    /// Get all registrations with pagination.
    /// </summary>
    [HttpGet("all")]
    public async Task<IActionResult> GetAll(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        CancellationToken ct = default)
    {
        if (page < 1) page = 1;
        if (pageSize < 1 || pageSize > 200) pageSize = 50;

        var (items, total) = await _registrationService.GetAllAsync(page, pageSize, ct);

        return Ok(new
        {
            Success = true,
            Data = items,
            Pagination = new
            {
                Page = page,
                PageSize = pageSize,
                TotalCount = total,
                TotalPages = (int)Math.Ceiling(total / (double)pageSize)
            }
        });
    }

    /// <summary>
    /// GET /api/registration/{id}
    /// Get a registration by its auto-incremented No.
    /// </summary>
    [HttpGet("{id:long}")]
    public async Task<IActionResult> GetById(long id, CancellationToken ct)
    {
        var result = await _registrationService.GetByIdAsync(id, ct);
        if (result is null)
            return NotFound(new { Success = false, Message = "Registration not found." });

        return Ok(new { Success = true, Data = result });
    }

    /// <summary>
    /// GET /api/registration/ticket/{ticketNo}
    /// Get a registration by ticket number.
    /// </summary>
    [HttpGet("ticket/{ticketNo}")]
    public async Task<IActionResult> GetByTicketNo(string ticketNo, CancellationToken ct)
    {
        var result = await _registrationService.GetByTicketNoAsync(ticketNo, ct);
        if (result is null)
            return NotFound(new { Success = false, Message = "Ticket not found." });

        return Ok(new { Success = true, Data = result });
    }
}
