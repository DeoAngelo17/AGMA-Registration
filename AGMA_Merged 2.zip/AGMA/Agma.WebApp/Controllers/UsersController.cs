using Agma.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agma.WebApp.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin")]
public class UsersController : ControllerBase
{
    private readonly IUserService _userService;

    public UsersController(IUserService userService)
    {
        _userService = userService;
    }

    /// <summary>
    /// GET /api/users
    /// List all users (Admin only).
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var users = await _userService.GetAllUsersAsync(ct);
        return Ok(new { Success = true, Data = users });
    }

    /// <summary>
    /// POST /api/users
    /// Create a new user (Admin only).
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateUserRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Username) || string.IsNullOrWhiteSpace(request.Password))
            return BadRequest(new { Success = false, Message = "Username and password are required." });

        if (request.Password.Length < 6)
            return BadRequest(new { Success = false, Message = "Password must be at least 6 characters." });

        var created = await _userService.CreateUserAsync(
            request.Username, request.Password, request.FullName, request.Email, request.RoleId, ct);

        if (!created)
            return Conflict(new { Success = false, Message = "Username already exists." });

        return Ok(new { Success = true, Message = "User created successfully." });
    }
}

/// <summary>Request body for creating a user.</summary>
public class CreateUserRequest
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public int RoleId { get; set; } = 2; // Default: Operator
}
