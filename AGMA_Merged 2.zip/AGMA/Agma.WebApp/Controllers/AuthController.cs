using Agma.Service.DTOs.Auth;
using Agma.Service.Interfaces;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agma.WebApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly IValidator<LoginRequestDto> _loginValidator;

    public AuthController(IAuthService authService, IValidator<LoginRequestDto> loginValidator)
    {
        _authService = authService;
        _loginValidator = loginValidator;
    }

    /// <summary>
    /// POST /api/auth/login
    /// Authenticates a user and returns a JWT token.
    /// </summary>
    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<IActionResult> Login([FromBody] LoginRequestDto request, CancellationToken ct)
    {
        var validation = await _loginValidator.ValidateAsync(request, ct);
        if (!validation.IsValid)
        {
            return BadRequest(new
            {
                Success = false,
                Errors = validation.Errors.Select(e => e.ErrorMessage)
            });
        }

        var result = await _authService.LoginAsync(request, ct);

        if (!result.Success)
            return Unauthorized(result);

        return Ok(result);
    }

    /// <summary>
    /// POST /api/auth/logout
    /// Client-side logout — invalidates the token on the client.
    /// (Stateless JWT; server doesn't maintain token state.)
    /// </summary>
    [HttpPost("logout")]
    [Authorize]
    public IActionResult Logout()
    {
        // With stateless JWT, logout is handled client-side by discarding the token.
        // This endpoint exists for API completeness and audit logging.
        return Ok(new { Success = true, Message = "Logged out successfully." });
    }
}
