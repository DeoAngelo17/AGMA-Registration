using Agma.Data.UnitOfWork;
using Agma.Service.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agma.WebApp.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class DashboardController : ControllerBase
{
    private readonly IUnitOfWork _uow;

    public DashboardController(IUnitOfWork uow)
    {
        _uow = uow;
    }

    /// <summary>
    /// GET /api/dashboard
    /// Returns dashboard statistics for the admin panel.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetDashboard(CancellationToken ct)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);

        var todayCount = await _uow.Registrations
            .CountAsync(r => r.Date == today && !r.IsVoided, ct);

        var overallCount = await _uow.Registrations
            .CountAsync(r => !r.IsVoided, ct);

        var dashboard = new DashboardViewModel
        {
            TotalRegistrationsToday = todayCount,
            TotalRegistrationsOverall = overallCount
        };

        return Ok(new { Success = true, Data = dashboard });
    }
}
