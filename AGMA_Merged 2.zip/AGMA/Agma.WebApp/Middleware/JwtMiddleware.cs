using Agma.Service.Helpers;

namespace Agma.WebApp.Middleware;

/// <summary>
/// Middleware that extracts and validates JWT tokens from the Authorization header.
/// Attaches the authenticated ClaimsPrincipal to HttpContext.User.
/// 
/// Note: This works alongside the built-in JWT Bearer authentication.
/// It provides an additional layer for custom validation logic if needed.
/// </summary>
public class JwtMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<JwtMiddleware> _logger;

    public JwtMiddleware(RequestDelegate next, ILogger<JwtMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context, JwtHelper jwtHelper)
    {
        var authHeader = context.Request.Headers.Authorization.FirstOrDefault();

        if (authHeader is not null && authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        {
            var token = authHeader["Bearer ".Length..].Trim();

            var principal = jwtHelper.ValidateToken(token);
            if (principal is not null)
            {
                context.User = principal;
                _logger.LogDebug("JWT validated for user: {User}",
                    principal.Identity?.Name ?? "unknown");
            }
            else
            {
                _logger.LogDebug("JWT validation failed for incoming token.");
            }
        }

        await _next(context);
    }
}
