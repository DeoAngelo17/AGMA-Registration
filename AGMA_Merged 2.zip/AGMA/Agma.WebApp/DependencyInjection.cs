using System.Text;
using Agma.Data.Context;
using Agma.Data.Repositories;
using Agma.Data.Repositories.Interfaces;
using Agma.Data.UnitOfWork;
using Agma.Service.Helpers;
using Agma.Service.Interfaces;
using Agma.Service.Mapping;
using Agma.Service.Services;
using Agma.Service.Validators;
using Agma.WebApp.Filters;
using FluentValidation;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace Agma.WebApp;

/// <summary>
/// Centralized DI registration for all application services.
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddAgmaServices(
        this IServiceCollection services, IConfiguration configuration)
    {
        // ── Database Contexts ──
        services.AddDbContext<AgmaDbContext>(options =>
            options.UseSqlServer(
                configuration.GetConnectionString("AGMADB"),
                sql => sql.CommandTimeout(60)
            ));

        services.AddDbContext<EbDataContext>(options =>
            options.UseSqlServer(
                configuration.GetConnectionString("EBDATA"),
                sql => sql.CommandTimeout(60)
            )
            .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking) // READ ONLY
        );

        // ── Unit of Work ──
        services.AddScoped<IUnitOfWork, UnitOfWork>();

        // ── Repositories ──
        services.AddScoped<IEBDataRepository, EBDataRepository>();

        // ── Services ──
        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<IAGMARegistrationService, AGMARegistrationService>();
        services.AddScoped<IEBDataService, EBDataService>();
        services.AddScoped<IReportService, ReportService>();
        services.AddScoped<IUserService, UserService>();

        // ── Helpers ──
        services.AddSingleton<JwtHelper>();

        // ── AutoMapper ──
        services.AddAutoMapper(typeof(AutoMapperProfile).Assembly);

        // ── FluentValidation ──
        services.AddValidatorsFromAssemblyContaining<RegisterAGMAValidator>();

        // ── Action Filters ──
        services.AddScoped<AuditActionFilter>();

        // ── JWT Authentication ──
        var jwtSection = configuration.GetSection("Jwt");
        var secret = jwtSection["Secret"] ?? throw new InvalidOperationException("JWT Secret not configured.");

        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(options =>
        {
            options.RequireHttpsMetadata = false; // Set to true in production
            options.SaveToken = true;
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret)),
                ValidateIssuer = true,
                ValidIssuer = jwtSection["Issuer"] ?? "AGMA",
                ValidateAudience = true,
                ValidAudience = jwtSection["Audience"] ?? "AGMA-WebApp",
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromMinutes(1)
            };
        });

        services.AddAuthorization();

        return services;
    }
}
